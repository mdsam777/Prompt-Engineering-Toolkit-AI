# Contributing to PromptForge

First off — **thank you!** PromptForge aims to be the most useful, best-documented
prompt-engineering toolkit on GitHub, and that only happens with community help.
This guide makes contributing as frictionless as possible.

There are three easy ways to contribute, in increasing order of effort:

1. **[Submit a prompt](#-add-a-prompt-to-the-library)** — share a great prompt.
2. **Improve the docs** — fix a typo, clarify a guide, add an example.
3. **Write code** — improve the engine, add a feature, fix a bug.

By participating you agree to abide by our [Code of Conduct](CODE_OF_CONDUCT.md).

---

## 🛠️ Project setup

The core engine is **pure Python with zero runtime dependencies** and requires
**Python 3.10+**. You do not need Node.js for the core.

```bash
# 1. Fork and clone
git clone https://github.com/<you>/promptforge.git
cd promptforge

# 2. (Recommended) create a virtual environment
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\Activate.ps1

# 3. Install the package with dev tooling
pip install -e ".[dev]"

# 4. Run the quality gate
pytest                 # tests
ruff check src tests   # lint
mypy src               # types
promptforge validate   # validate the prompt library
```

> No internet or can't install? The tests also run with only the standard
> library: `PYTHONPATH=src python -m unittest discover -s tests`.

---

## 📝 Add a prompt to the library

This is the highest-impact, lowest-friction contribution. Every prompt lives as
JSON under `prompts/data/<category>/` and must satisfy
[`prompts/schema/prompt.schema.json`](prompts/schema/prompt.schema.json).

1. Pick or create a category folder, e.g. `prompts/data/marketing/`.
2. Add your prompt to the category's `.json` file (an array of prompt objects),
   or create a new file. **One concept per prompt.**
3. Fill in **every** required field — this is what makes the library special:

   | Field | Required | Notes |
   |-------|:--------:|-------|
   | `id` | ✅ | lowercase-hyphenated, unique across the library |
   | `title` | ✅ | human-readable name |
   | `description` | ✅ | ≤ 280 chars |
   | `category` | ✅ | matches the folder slug |
   | `difficulty` | ✅ | `beginner` \| `intermediate` \| `advanced` \| `expert` |
   | `body` | ✅ | the prompt text; use `{placeholders}` for variables |
   | `expected_output` | ✅ | what a good response looks like |
   | `supported_models` | ✅ | model ids or `["all"]` |
   | `example` | ✅ | a concrete, filled-in example |
   | `best_practices` | ✅ | tips that make it perform |
   | `common_mistakes` | ✅ | pitfalls to avoid |
   | `version` | ✅ | semantic, start at `1.0.0` |
   | `tags` | ✅ | search keywords |
   | `related_prompts` | optional | ids of complementary prompts |

4. Validate locally:

   ```bash
   promptforge validate
   ```

5. Open a pull request. CI re-runs validation automatically.

> **Quality bar:** prompts should follow the patterns in our
> [Prompt Engineering Guide](docs/guide/README.md) — clear role, context,
> explicit constraints and a defined output format. Tip: run
> `promptforge score --file your_prompt.txt` on the `body` to sanity-check it.

---

## 💻 Code contributions

* Keep the **core engine dependency-free**. New runtime dependencies need a
  strong justification and a maintainer's approval.
* Match the existing style: clear names, docstrings on public functions, and
  comments that explain *why*, not *what*.
* Add or update **tests** for any behaviour change. We aim to keep the suite
  green and fast.
* Run `ruff check` and `mypy` before pushing.
* Keep pull requests focused — one logical change per PR.

### Commit messages

We loosely follow [Conventional Commits](https://www.conventionalcommits.org/):

```
feat(optimizer): add reasoning section for complex tasks
fix(library): handle empty category directories
docs(guide): expand the few-shot section
prompt(seo): add internal-linking prompt
```

---

## 🔀 Pull request process

1. Create a branch: `git checkout -b feat/short-description`.
2. Make your change with tests and docs.
3. Ensure the quality gate passes locally.
4. Push and open a PR using the template; link any related issue.
5. A maintainer will review. Be ready for a round or two of friendly feedback.

Thanks again for helping build PromptForge! 🚀
