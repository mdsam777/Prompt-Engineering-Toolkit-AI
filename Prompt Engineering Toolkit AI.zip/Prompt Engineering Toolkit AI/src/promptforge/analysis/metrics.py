"""Per-dimension metric analyzers used by the scoring engine.

Each public function in this module takes the prompt text plus its precomputed
:class:`~promptforge.analysis.text_stats.TextStats` and returns a
:class:`MetricResult`: a 0-100 sub-score together with the concrete *findings*
(what was detected) and *suggestions* (how to improve). The scoring engine
(:mod:`promptforge.analysis.scoring`) combines these into the final 100-point
result, and the optimizer reuses the findings to decide which rewrites to apply.

All logic is deterministic and explainable. A given prompt always yields the
same scores, which makes the engine usable in CI gates and unit tests.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from .text_stats import TextStats

# Structural markdown markers: headings, bullets, numbered items, code fences.
_STRUCTURE_RE = re.compile(r"(^|\n)\s*(#{1,6}\s|[-*]\s|\d+[.)]\s|```)", re.MULTILINE)
_NUMBER_RE = re.compile(r"\d")

# Prompt-injection / jailbreak markers. Their presence lowers the safety score
# because they make a prompt brittle and policy-violating, not because the topic
# itself is forbidden. This is a static lint signal, not a content classifier.
_RISKY_PATTERNS = (
    "ignore previous instructions",
    "ignore all previous",
    "ignore the above",
    "disregard your instructions",
    "disregard all rules",
    "bypass your",
    "without any restrictions",
    "no restrictions",
    "you have no rules",
    "pretend you have no",
    "jailbreak",
    "do anything now",
)


@dataclass(slots=True)
class MetricResult:
    """The outcome of evaluating one scoring dimension.

    Attributes:
        name: Dimension name (e.g. ``"clarity"``).
        score: Sub-score in the inclusive range 0-100.
        findings: What the analyzer observed (neutral, factual).
        suggestions: Actionable ways to raise the score.
    """

    name: str
    score: float
    findings: list[str] = field(default_factory=list)
    suggestions: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        # Defensive clamp so a buggy heuristic can never escape 0-100.
        self.score = round(max(0.0, min(100.0, self.score)), 1)


def _has_structure(text: str) -> bool:
    """Return ``True`` if the prompt uses headings, lists or code fences."""
    return bool(_STRUCTURE_RE.search(text))


def _redundancy_ratio(stats: TextStats) -> float:
    """Estimate repeated-trigram redundancy in ``[0, 1]`` (higher = more)."""
    words = re.findall(r"[a-z0-9']+", stats.text.lower())
    if len(words) < 6:
        return 0.0
    trigrams = list(zip(words, words[1:], words[2:]))
    unique = len(set(trigrams))
    return round(1 - unique / len(trigrams), 3)


# --- Individual dimensions ------------------------------------------------
def clarity(stats: TextStats) -> MetricResult:
    """How easy the prompt is to read and unambiguously interpret.

    Driven by readability, sentence length and the density of vague qualifiers.
    """
    score = 100.0
    findings: list[str] = []
    suggestions: list[str] = []

    if stats.avg_sentence_len > 24:
        penalty = min(30.0, (stats.avg_sentence_len - 24) * 2.0)
        score -= penalty
        findings.append(
            f"Average sentence length is {stats.avg_sentence_len} words."
        )
        suggestions.append("Break long sentences into shorter, direct instructions.")
    if stats.vague_count:
        score -= min(40.0, stats.vague_count * 9.0)
        findings.append(f"Found {stats.vague_count} vague qualifier(s).")
        suggestions.append(
            "Replace vague words (e.g. 'good', 'some', 'appropriate') with "
            "concrete criteria."
        )
    if stats.flesch_reading_ease < 25 and stats.word_count > 15:
        score -= 10.0
        findings.append("Readability is low (dense wording).")
        suggestions.append("Simplify vocabulary and trim nested clauses.")
    if not findings:
        findings.append("Wording is concise and unambiguous.")
    return MetricResult("clarity", score, findings, suggestions)


def specificity(stats: TextStats) -> MetricResult:
    """How concrete and detailed the request is."""
    score = 45.0
    findings: list[str] = []
    suggestions: list[str] = []

    score += min(30.0, stats.constraint_count * 8.0)
    if stats.constraint_count:
        findings.append(f"{stats.constraint_count} explicit constraint(s) present.")
    else:
        suggestions.append("Add explicit constraints (length, scope, must/avoid).")

    if _NUMBER_RE.search(stats.text):
        score += 12.0
        findings.append("Includes concrete numeric detail.")
    else:
        suggestions.append("Quantify expectations where possible (counts, limits).")

    if stats.word_count >= 25:
        score += 13.0
    elif stats.word_count < 8:
        score -= 10.0
        findings.append("Prompt is very short, leaving intent underspecified.")
        suggestions.append("Describe the task, audience and success criteria.")

    if stats.vague_count:
        score -= min(25.0, stats.vague_count * 8.0)

    if not findings:
        findings.append("Request is reasonably specific.")
    return MetricResult("specificity", score, findings, suggestions)


def reasoning(stats: TextStats) -> MetricResult:
    """Whether the prompt invites the model to justify or work through its answer."""
    findings: list[str] = []
    suggestions: list[str] = []
    if stats.has_reasoning:
        score = 92.0
        findings.append("Prompt asks the model to reason or explain.")
    elif stats.has_examples:
        score = 68.0
        findings.append("Examples provide implicit reasoning scaffolding.")
        suggestions.append("Ask the model to explain its reasoning for harder tasks.")
    else:
        score = 50.0
        findings.append("No explicit request for reasoning or justification.")
        suggestions.append(
            "For non-trivial tasks, ask the model to reason before answering."
        )
    return MetricResult("reasoning", score, findings, suggestions)


def chain_of_thought(stats: TextStats) -> MetricResult:
    """Readiness for step-by-step / chain-of-thought decomposition."""
    findings: list[str] = []
    suggestions: list[str] = []
    hits = stats.cue_hits.get("reasoning", 0)
    if hits >= 2:
        score = 95.0
        findings.append("Strong step-by-step decomposition cues present.")
    elif hits == 1:
        score = 78.0
        findings.append("A step-by-step cue is present.")
    else:
        score = 48.0
        findings.append("No explicit step-by-step instruction.")
        suggestions.append(
            "Add 'think step by step' or enumerate the steps to decompose the task."
        )
    return MetricResult("chain_of_thought", score, findings, suggestions)


def context(stats: TextStats) -> MetricResult:
    """Whether enough background and role framing is supplied."""
    score = 40.0
    findings: list[str] = []
    suggestions: list[str] = []

    if stats.has_role:
        score += 25.0
        findings.append("A role/persona is assigned to the model.")
    else:
        suggestions.append("Assign a clear role (e.g. 'You are a senior data analyst').")
    if stats.has_context:
        score += 25.0
        findings.append("Background/context is provided.")
    else:
        suggestions.append("Provide background: who, what, why, and any constraints.")
    if stats.word_count >= 30:
        score += 10.0
    if not (stats.has_role or stats.has_context):
        findings.append("Neither role nor background context is present.")
    return MetricResult("context", score, findings, suggestions)


def formatting(stats: TextStats) -> MetricResult:
    """Whether the desired output format/structure is specified."""
    score = 45.0
    findings: list[str] = []
    suggestions: list[str] = []

    if stats.has_format:
        score += 35.0
        findings.append("An explicit output format is requested.")
    else:
        suggestions.append(
            "State the output format (JSON, table, bullet list, headings, ...)."
        )
    if _has_structure(stats.text):
        score += 20.0
        findings.append("Prompt itself uses clear structure (lists/headings).")
    else:
        suggestions.append("Structure the prompt with sections or bullet points.")
    if not findings:
        findings.append("No format or structure detected.")
    return MetricResult("formatting", score, findings, suggestions)


def token_efficiency(stats: TextStats) -> MetricResult:
    """How economically the prompt uses tokens (filler and redundancy)."""
    score = 100.0
    findings: list[str] = []
    suggestions: list[str] = []

    if stats.filler_count:
        score -= min(35.0, stats.filler_count * 7.0)
        findings.append(f"{stats.filler_count} filler/politeness phrase(s) detected.")
        suggestions.append(
            "Remove filler ('please', 'just', 'I would like you to'); be direct."
        )
    redundancy = _redundancy_ratio(stats)
    if redundancy > 0.15:
        score -= min(30.0, redundancy * 80.0)
        findings.append(f"Repeated phrasing detected (redundancy {redundancy}).")
        suggestions.append("Remove repeated instructions; state each rule once.")
    if stats.estimated_tokens > 800:
        score -= 10.0
        findings.append(f"Prompt is long (~{stats.estimated_tokens} tokens).")
        suggestions.append("Trim non-essential detail to save context budget.")
    if not findings:
        findings.append(f"Lean prompt (~{stats.estimated_tokens} tokens).")
    return MetricResult("token_efficiency", score, findings, suggestions)


def safety(stats: TextStats) -> MetricResult:
    """Static check for prompt-injection / jailbreak phrasing.

    A low score flags phrasing that tries to override system instructions, which
    makes prompts brittle and policy-violating. It does **not** judge the topic.
    """
    lowered = stats.text.lower()
    hits = [p for p in _RISKY_PATTERNS if p in lowered]
    if hits:
        score = max(10.0, 90.0 - len(hits) * 25.0)
        findings = [f"Contains override/jailbreak phrasing: {hits[0]!r}."]
        suggestions = [
            "Avoid instructing the model to ignore or bypass its guidelines; "
            "frame requests within policy.",
        ]
    else:
        score = 95.0
        findings = ["No prompt-injection or override phrasing detected."]
        suggestions = []
    return MetricResult("safety", score, findings, suggestions)


def reliability(stats: TextStats) -> MetricResult:
    """How likely the prompt is to yield consistent, on-spec results.

    Constraints, examples and a defined output format all reduce variance.
    """
    score = 35.0
    findings: list[str] = []
    suggestions: list[str] = []

    if stats.constraint_count:
        score += min(25.0, stats.constraint_count * 7.0)
    else:
        suggestions.append("Add constraints to bound the response.")
    if stats.has_examples:
        score += 20.0
        findings.append("Examples anchor the expected response.")
    else:
        suggestions.append("Add at least one worked example (few-shot).")
    if stats.has_format:
        score += 20.0
    else:
        suggestions.append("Pin the output format to make parsing reliable.")
    if not findings:
        findings.append("Few variance-reducing signals present.")
    return MetricResult("reliability", score, findings, suggestions)


def output_consistency(stats: TextStats) -> MetricResult:
    """Whether repeated runs would produce comparably-shaped output."""
    score = 40.0
    findings: list[str] = []
    suggestions: list[str] = []

    if stats.has_format:
        score += 30.0
        findings.append("Output format is specified.")
    else:
        suggestions.append("Specify an exact output schema/format.")
    if stats.has_examples:
        score += 20.0
        findings.append("Example output shapes the response.")
    else:
        suggestions.append("Show a sample of the exact output you expect.")
    if stats.constraint_count >= 2:
        score += 10.0
    if not findings:
        findings.append("Output shape is left to the model's discretion.")
    return MetricResult("output_consistency", score, findings, suggestions)


#: Ordered registry of every dimension analyzer. The scoring engine iterates
#: this so adding a dimension is a one-line change.
ANALYZERS = (
    clarity,
    specificity,
    reasoning,
    chain_of_thought,
    context,
    formatting,
    token_efficiency,
    safety,
    reliability,
    output_consistency,
)
