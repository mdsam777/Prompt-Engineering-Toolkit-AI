# Security Policy

## Supported Versions

PromptForge is in active development. Security fixes are applied to the latest
release on the `main` branch.

| Version | Supported |
| ------- | --------- |
| 0.1.x   | ✅        |

## Reporting a Vulnerability

**Please do not report security vulnerabilities through public GitHub issues.**

Instead, use GitHub's private
[**Report a vulnerability**](https://github.com/promptforge/promptforge/security/advisories/new)
flow (Security → Advisories), or email the maintainers privately if listed in
the repository profile.

When reporting, please include:

* A description of the vulnerability and its impact.
* Steps to reproduce (proof-of-concept if possible).
* The affected version(s) and environment.

We aim to acknowledge reports within **72 hours** and to provide a remediation
timeline after triage. We will credit reporters who wish to be acknowledged.

## Scope notes

The core engine performs **static, offline analysis of prompt text** and makes
no network calls. The "safety" score is a heuristic lint for prompt-injection
phrasing, not a security guarantee. When you wire PromptForge to real model
APIs in your own application, treat all model output as untrusted and apply your
own validation and sandboxing.
