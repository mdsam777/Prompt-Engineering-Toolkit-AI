"""Tests for the chat assistant brain (promptforge.assistant)."""

from __future__ import annotations

import unittest

from promptforge.assistant import respond


class AssistantTests(unittest.TestCase):
    def test_greeting_returns_welcome(self) -> None:
        for greeting in ("", "hi", "hello", "start", "what can you do?"):
            reply = respond(greeting)
            self.assertEqual(reply.kind, "greeting")
            self.assertIn("Prompt Engineering Toolkit", reply.text)

    def test_generate_from_requirement(self) -> None:
        reply = respond("Write a prompt for a cold sales email to SaaS founders")
        self.assertEqual(reply.kind, "generate")
        self.assertIn("## Role", reply.text)
        self.assertIn("```", reply.text)
        self.assertTrue(reply.suggestions)

    def test_generate_strips_modifier_phrases(self) -> None:
        # Style modifiers should be applied, not echoed into the Task text.
        reply = respond("Write a prompt for a cold email to founders, friendly tone, short")
        self.assertIn("friendly tone", reply.text.lower())  # tone applied in Context
        task_line = next(
            (ln for ln in reply.text.splitlines() if "cold email to founders" in ln.lower()),
            "",
        )
        self.assertNotIn("friendly tone", task_line.lower())
        self.assertNotIn(", short", task_line.lower())

    def test_optimize_command(self) -> None:
        reply = respond("optimize: write code")
        self.assertEqual(reply.kind, "optimize")
        self.assertIn("Improved prompt", reply.text)
        self.assertIn("→", reply.text)

    def test_score_command(self) -> None:
        reply = respond("score: write a blog post about coffee")
        self.assertEqual(reply.kind, "score")
        self.assertIn("Overall", reply.text)

    def test_search_natural_language(self) -> None:
        reply = respond("find prompts about sql")
        self.assertEqual(reply.kind, "search")
        self.assertIn("sql-query-builder", reply.text)

    def test_show_prompt(self) -> None:
        reply = respond("show sql-query-builder")
        self.assertEqual(reply.kind, "show")
        self.assertIn("SQL", reply.text)

    def test_show_unknown_prompt(self) -> None:
        reply = respond("show not-a-real-id")
        self.assertEqual(reply.kind, "show")
        self.assertIn("don't have a prompt", reply.text)

    def test_refinement_uses_history(self) -> None:
        history = [
            {"role": "user", "content": "Write a prompt for a marketing email"},
            {"role": "assistant", "content": "Here's an optimised prompt ..."},
        ]
        reply = respond("make it shorter", history)
        self.assertEqual(reply.kind, "generate")
        # The short preset caps the word budget at ~120 words.
        self.assertIn("120 words", reply.text)

    def test_refinement_without_history_falls_back(self) -> None:
        # No prior requirement: "shorter" alone should not crash, just generate.
        reply = respond("shorter")
        self.assertIn(reply.kind, {"generate", "greeting"})


if __name__ == "__main__":
    unittest.main()
