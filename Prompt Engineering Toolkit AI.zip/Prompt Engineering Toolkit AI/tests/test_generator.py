"""Tests for the prompt generator (promptforge.generator)."""

from __future__ import annotations

import unittest

from promptforge.generator import GeneratorSpec, generate


class GeneratorTests(unittest.TestCase):
    def test_generates_structured_prompt(self) -> None:
        spec = GeneratorSpec(goal="Explain SQL common table expressions",
                             industry="data", length="short")
        result = generate(spec)
        for section in ("## Role", "## Context", "## Task",
                        "## Constraints", "## Output Format"):
            self.assertIn(section, result.prompt)

    def test_generated_prompt_scores_well(self) -> None:
        result = generate(GeneratorSpec(goal="Write a cold outreach email"))
        self.assertIsNotNone(result.score)
        self.assertGreaterEqual(result.score.overall, 60)

    def test_empty_goal_raises(self) -> None:
        with self.assertRaises(ValueError):
            generate(GeneratorSpec(goal="   "))

    def test_unknown_length_raises(self) -> None:
        with self.assertRaises(ValueError):
            generate(GeneratorSpec(goal="x", length="enormous"))

    def test_model_note_added(self) -> None:
        result = generate(GeneratorSpec(goal="x", model="claude"))
        self.assertTrue(any("claude" in n.lower() for n in result.notes))

    def test_language_propagates(self) -> None:
        result = generate(GeneratorSpec(goal="x", language="Spanish"))
        self.assertIn("Spanish", result.prompt)


if __name__ == "__main__":
    unittest.main()
