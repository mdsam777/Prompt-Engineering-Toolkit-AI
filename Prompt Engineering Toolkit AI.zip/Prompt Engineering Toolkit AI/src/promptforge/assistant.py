"""The conversational brain behind the chat app.

This module turns a free-text user message into a helpful reply, powered entirely
by the offline PromptForge engine. It is the "AI" the user chats with in the
browser app — a focused *prompt-engineering assistant*, not a general LLM:

* Describe a requirement  -> it **generates** an optimised, structured prompt.
* Paste a prompt + "optimize" -> it **rewrites** it and shows the improvement.
* "score: <prompt>"       -> it **rates** the prompt across 10 dimensions.
* "find prompts about X"   -> it **searches** the bundled library.
* "show <id>"              -> it shows a full library prompt.

Everything is deterministic and runs without API keys or network access, so the
desktop launcher works on any machine with Python. The reply text is Markdown so
the web UI can render code blocks (the prompts) with copy buttons.

The design keeps a clean seam where a real LLM backend could later be plugged in
(see :func:`respond`): the routing and prompt-building would stay identical.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Iterable

from .analysis.optimizer import optimize
from .analysis.scoring import score_prompt
from .generator import GeneratorSpec, generate
from .library import PromptLibrary
from .models import REGISTRY

# Lazily-loaded singleton so the library is read from disk only once per process.
_LIBRARY: PromptLibrary | None = None

# Lead-ins we strip when a user phrases a requirement as a request, so the
# generated prompt's goal is the bare intent ("write a blog post" not
# "can you give me a prompt for write a blog post").
_LEADINS = re.compile(
    r"^\s*(?:please\s+)?(?:can you|could you|would you|i (?:want|need|would like)|"
    r"help me|give me|make me|create|generate|write|build|design|craft)?\s*"
    r"(?:an?\s+)?(?:optimi[sz]ed\s+)?(?:prompt|prompts)?\s*"
    r"(?:for|to|that|which|about)?\s*[:\-]?\s*",
    re.IGNORECASE,
)

# Words that mean "tweak the previous prompt" rather than "new requirement".
_REFINE_RE = re.compile(
    r"\b(shorter|longer|concise|brief|detailed|comprehensive|in[- ]depth|"
    r"friendl(?:y|ier)|formal|professional|casual|persuasive|technical|simpler|"
    r"more detail|less detail|expand|trim)\b",
    re.IGNORECASE,
)

_GREETINGS = {
    "hi", "hello", "hey", "yo", "start", "help", "?", "hi there", "hello there",
    "what can you do", "what can you do?", "menu", "begin",
}


@dataclass(slots=True)
class AssistantReply:
    """A single assistant turn.

    Attributes:
        text: Markdown reply rendered by the web UI.
        suggestions: Quick-reply chips offered to the user.
        kind: Coarse label (greeting/generate/optimize/score/search/show/help)
            mainly useful for analytics and tests.
    """

    text: str
    suggestions: list[str] = field(default_factory=list)
    kind: str = "generate"

    def to_dict(self) -> dict[str, object]:
        return {"text": self.text, "suggestions": self.suggestions, "kind": self.kind}


def _library() -> PromptLibrary:
    global _LIBRARY
    if _LIBRARY is None:
        try:
            _LIBRARY = PromptLibrary.load()
        except FileNotFoundError:
            _LIBRARY = PromptLibrary([])  # empty library is still usable
    return _LIBRARY


# --- helpers --------------------------------------------------------------
def _detect_length(text: str) -> str | None:
    lowered = text.lower()
    if re.search(r"\b(short|shorter|brief|concise|tl;?dr|one[- ]liner)\b", lowered):
        return "short"
    if re.search(r"\b(long|longer|detailed|comprehensive|in[- ]depth|thorough|expand)\b", lowered):
        return "long"
    return None


def _detect_tone(text: str) -> str | None:
    lowered = text.lower()
    if re.search(r"\b(friendl|casual|conversational|warm)\w*", lowered):
        return "friendly"
    if re.search(r"\b(formal|professional|business|corporate)\w*", lowered):
        return "professional"
    if re.search(r"\b(persuasive|sales|convincing|compelling)\w*", lowered):
        return "persuasive"
    if re.search(r"\b(technical|precise|rigorous)\w*", lowered):
        return "technical"
    return None


def _detect_model(text: str) -> str | None:
    lowered = text.lower()
    aliases = {
        "chatgpt": "gpt", "gpt": "gpt", "openai": "gpt",
        "claude": "claude", "anthropic": "claude",
        "gemini": "gemini", "google": "gemini",
        "grok": "grok", "deepseek": "deepseek", "llama": "llama",
        "mistral": "mistral", "qwen": "qwen", "perplexity": "perplexity",
    }
    for alias, model_id in aliases.items():
        if re.search(rf"\b{re.escape(alias)}\b", lowered) and model_id in REGISTRY:
            return model_id
    return None


def _parse_modifiers(text: str) -> dict[str, str]:
    """Extract any generation overrides (length/tone/model) mentioned in ``text``."""
    mods: dict[str, str] = {}
    if (length := _detect_length(text)):
        mods["length"] = length
    if (tone := _detect_tone(text)):
        mods["tone"] = tone
    if (model := _detect_model(text)):
        mods["model"] = model
    return mods


def _clean_goal(text: str) -> str:
    """Strip request lead-ins to recover the bare task description."""
    cleaned = _LEADINS.sub("", text, count=1).strip()
    # If stripping removed everything (message was only a lead-in), keep original.
    return cleaned or text.strip()


def _strip_modifier_phrases(goal: str) -> str:
    """Remove short comma-separated modifier clauses (e.g. ", friendly tone").

    Keeps the core requirement clean so it doesn't echo style instructions that
    are already applied via the spec. Only drops short segments (<= 4 words) that
    are purely about tone/length, never the substantive part of the goal.
    """
    parts = [p.strip() for p in goal.split(",")]
    kept = [
        p for p in parts
        if not (p and len(p.split()) <= 4 and (_detect_length(p) or _detect_tone(p)))
    ]
    return ", ".join(p for p in kept if p) or goal


def _last_requirement(history: Iterable[dict]) -> str | None:
    """Find the most recent real requirement in the conversation history."""
    for turn in reversed(list(history or [])):
        if turn.get("role") != "user":
            continue
        content = str(turn.get("content", "")).strip()
        if not content or content.lower() in _GREETINGS:
            continue
        # Skip pure refinement messages — they aren't the underlying goal.
        if _REFINE_RE.search(content) and len(content.split()) <= 6:
            continue
        if content.lower().split(":", 1)[0] in {"optimize", "improve", "score", "rate", "search", "find", "show", "open"}:
            continue
        return _clean_goal(content)
    return None


# --- intent handlers ------------------------------------------------------
def _welcome() -> AssistantReply:
    text = (
        "## 👋 Welcome to the Prompt Engineering Toolkit\n\n"
        "I turn your plain-English requirements into **ready-to-use, optimised "
        "prompts** for ChatGPT, Claude, Gemini and other models — and I can score "
        "or improve prompts you already have.\n\n"
        "**Try saying things like:**\n"
        "- *Write a prompt for a cold sales email to SaaS founders*\n"
        "- *I need a prompt to summarise research papers*\n"
        "- *optimize: <paste your prompt here>*\n"
        "- *score: <paste your prompt here>*\n"
        "- *find prompts about SEO*\n\n"
        "What would you like a prompt for?"
    )
    return AssistantReply(
        text=text,
        suggestions=[
            "Write a prompt for a marketing email",
            "I need a prompt to debug Python code",
            "find prompts about data analysis",
        ],
        kind="greeting",
    )


def _format_score_block(score) -> str:
    """Render a compact score summary as Markdown."""
    top_weak = sorted(score.dimensions.values(), key=lambda m: m.score)[:3]
    weak = ", ".join(f"{m.name} ({m.score:.0f})" for m in top_weak)
    return (
        f"**Quality score:** {score.overall}/100  ·  grade **{score.grade}**\n\n"
        f"Weakest areas: {weak}"
    )


def _do_generate(goal: str, mods: dict[str, str]) -> AssistantReply:
    goal = _strip_modifier_phrases(goal)
    spec = GeneratorSpec(
        goal=goal,
        length=mods.get("length", "medium"),
        tone=mods.get("tone", "professional"),
        model=mods.get("model", "all"),
    )
    result = generate(spec)
    target = ""
    if spec.model != "all":
        target = f" (tuned for **{spec.model}**)"
    text = (
        f"Here's an optimised prompt for *{goal}*{target}:\n\n"
        f"```text\n{result.prompt}\n```\n\n"
        f"{_format_score_block(result.score)}\n\n"
        "Want me to adjust it?"
    )
    return AssistantReply(
        text=text,
        suggestions=["Make it shorter", "Use a friendly tone", "Target Claude",
                     "Add few-shot examples idea"],
        kind="generate",
    )


def _do_optimize(prompt_text: str) -> AssistantReply:
    if not prompt_text.strip():
        return AssistantReply(
            text="Paste the prompt you'd like me to improve, like:\n\n"
                 "`optimize: You are a helpful assistant. Write a tweet.`",
            suggestions=[], kind="optimize",
        )
    result = optimize(prompt_text)
    before = result.before.overall if result.before else 0
    after = result.after.overall if result.after else 0
    changes = "\n".join(f"- {c}" for c in result.changes)
    text = (
        f"**Optimised!** Score **{before} → {after}** (▲ {result.delta}).\n\n"
        f"**What I changed:**\n{changes}\n\n"
        f"**Improved prompt:**\n\n```text\n{result.improved}\n```"
    )
    return AssistantReply(text=text, suggestions=["Score this prompt", "Make it shorter"],
                          kind="optimize")


def _do_score(prompt_text: str) -> AssistantReply:
    if not prompt_text.strip():
        return AssistantReply(
            text="Paste the prompt you'd like me to score, like:\n\n"
                 "`score: Write a blog post about coffee.`",
            suggestions=[], kind="score",
        )
    score = score_prompt(prompt_text)
    lines = [f"- **{m.name}** — {m.score:.0f}/100" for m in score.dimensions.values()]
    tips = "\n".join(f"- {s}" for s in score.suggestions[:5]) or "- Looks solid!"
    text = (
        f"**Overall: {score.overall}/100 (grade {score.grade})**\n\n"
        + "\n".join(lines)
        + f"\n\n**Top suggestions:**\n{tips}"
    )
    return AssistantReply(text=text, suggestions=["Optimize this prompt"], kind="score")


def _do_search(query: str) -> AssistantReply:
    lib = _library()
    hits = lib.search(query, limit=6)
    if not hits:
        return AssistantReply(
            text=f"I couldn't find library prompts matching *{query}*. "
                 "Try a broader term, or describe what you need and I'll generate one.",
            suggestions=["Write a prompt for " + query] if query else [],
            kind="search",
        )
    lines = [
        f"- **{h.prompt.title}** (`{h.prompt.id}`) — {h.prompt.description}"
        for h in hits
    ]
    text = (
        f"Found **{len(hits)}** prompt(s) for *{query}*:\n\n"
        + "\n".join(lines)
        + "\n\nType `show <id>` to see the full prompt."
    )
    suggestions = [f"show {hits[0].prompt.id}"] if hits else []
    return AssistantReply(text=text, suggestions=suggestions, kind="search")


def _do_show(prompt_id: str) -> AssistantReply:
    prompt = _library().get(prompt_id.strip())
    if prompt is None:
        return AssistantReply(
            text=f"I don't have a prompt with id `{prompt_id}`. "
                 "Try `find prompts about <topic>` to browse.",
            suggestions=[], kind="show",
        )
    bp = "\n".join(f"- {x}" for x in prompt.best_practices) or "- —"
    cm = "\n".join(f"- {x}" for x in prompt.common_mistakes) or "- —"
    text = (
        f"## {prompt.title}\n"
        f"*{prompt.description}*\n\n"
        f"**Category:** {prompt.category}  ·  **Difficulty:** {prompt.difficulty.value}  "
        f"·  **Models:** {', '.join(prompt.supported_models)}\n\n"
        f"**Prompt:**\n\n```text\n{prompt.body}\n```\n\n"
        f"**Best practices:**\n{bp}\n\n"
        f"**Common mistakes:**\n{cm}"
    )
    return AssistantReply(text=text, suggestions=["Optimize this prompt"], kind="show")


# --- public entry point ---------------------------------------------------
def respond(message: str, history: list[dict] | None = None) -> AssistantReply:
    """Produce an assistant reply for ``message`` given prior ``history``.

    Args:
        message: The latest user message.
        history: Prior turns as ``[{"role": "user"|"assistant", "content": str}]``.

    Returns:
        An :class:`AssistantReply`. Never raises on normal input.
    """
    msg = (message or "").strip()
    if not msg or msg.lower() in _GREETINGS:
        return _welcome()

    # Explicit command prefixes take priority (used by the UI quick actions).
    head, _, tail = msg.partition(":")
    command = head.strip().lower()
    if command in {"optimize", "improve"}:
        return _do_optimize(tail.strip() or msg)
    if command in {"score", "rate"}:
        return _do_score(tail.strip() or msg)
    if command in {"search", "find"}:
        return _do_search(tail.strip())
    if command in {"show", "open"}:
        return _do_show(tail.strip())

    # Natural-language "find/show" without a colon.
    if (m := re.match(r"(?:find|search|browse|show me)\s+(?:prompts?\s+)?(?:about\s+|for\s+|on\s+)?(.+)", msg, re.IGNORECASE)):
        return _do_search(m.group(1).strip())
    if (m := re.match(r"(?:show|open)\s+([a-z0-9-]+)$", msg, re.IGNORECASE)):
        return _do_show(m.group(1).strip())

    # Refinement of the previous prompt ("make it shorter", "use claude").
    mods = _parse_modifiers(msg)
    is_refinement = bool(_REFINE_RE.search(msg) or _detect_model(msg)) and len(msg.split()) <= 8
    if is_refinement:
        goal = _last_requirement(history or [])
        if goal:
            return _do_generate(goal, mods)
        # No prior goal to refine — fall through to treat as a new requirement.

    # Default: treat the message as a requirement and generate a prompt.
    return _do_generate(_clean_goal(msg), mods)
