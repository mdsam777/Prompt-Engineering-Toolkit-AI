@echo off
REM ============================================================
REM   Prompt Engineering Toolkit - one-click launcher (Windows)
REM   Double-click this file to open the chat app in your browser.
REM ============================================================
title Prompt Engineering Toolkit
cd /d "%~dp0"

echo Starting the Prompt Engineering Toolkit...
echo.

REM Prefer the "python" command; fall back to the "py" launcher.
where python >nul 2>nul
if %errorlevel%==0 (
    python "%~dp0start.py"
    goto :end
)

where py >nul 2>nul
if %errorlevel%==0 (
    py "%~dp0start.py"
    goto :end
)

echo Python was not found on your system.
echo Please install Python 3.10 or newer from https://www.python.org/downloads/
echo (During install, tick "Add Python to PATH"), then double-click this file again.

:end
echo.
pause
