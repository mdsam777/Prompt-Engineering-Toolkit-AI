"""Tests for the optimizer (promptforge.analysis.optimizer)."""

from __future__ import annotations

import unittest

from promptforge.analysis.optimizer import infer_role, optimize


class OptimizerTests(unittest.TestCase):
    def test_optimize_improves_weak_prompt(self) -> None:
        result = optimize("write code")
        self.assertIsNotNone(result.before)
        self.assertIsNotNone(result.after)
        self.assertGreater(result.after.overall, result.before.overall)
        self.assertGreater(result.delta, 0)

    def test_adds_structural_sections(self) -> None:
        improved = optimize("summarize this article").improved
        self.assertIn("## Role", improved)
        self.assertIn("## Output Format", improved)
        self.assertIn("## Task", improved)

    def test_removes_filler(self) -> None:
        result = optimize("Please kindly just write a function for me")
        self.assertTrue(any("filler" in c.lower() for c in result.changes))

    def test_respects_existing_role(self) -> None:
        prompt = "You are a senior engineer. Refactor this function for clarity."
        result = optimize(prompt)
        self.assertTrue(any("existing role" in c.lower() for c in result.changes))

    def test_output_format_override(self) -> None:
        improved = optimize("classify the sentiment", output_format="JSON").improved
        self.assertIn("JSON", improved)

    def test_infer_role_keywords(self) -> None:
        self.assertIn("software engineer", infer_role("debug this python code"))
        self.assertIn("marketing", infer_role("plan a marketing campaign"))
        self.assertEqual(infer_role("xyzzy"), "an expert assistant")

    def test_serialisation(self) -> None:
        data = optimize("write code").to_dict()
        self.assertIn("improved", data)
        self.assertIn("changes", data)
        self.assertIn("delta", data)


if __name__ == "__main__":
    unittest.main()
