"""Prompt analysis engine: text statistics, scoring and optimisation.

Public API::

    from promptforge.analysis import score_prompt, optimize, analyze_text

* :func:`score_prompt` — rate a prompt across 10 dimensions (0-100 + grade).
* :func:`optimize` — rewrite a prompt into a structured, higher-scoring form.
* :func:`analyze_text` — low-level deterministic text statistics.
"""

from __future__ import annotations

from .metrics import MetricResult
from .optimizer import OptimizedPrompt, optimize
from .scoring import WEIGHTS, ScoreResult, score_prompt
from .text_stats import TextStats, analyze_text, estimate_tokens

__all__ = [
    "MetricResult",
    "OptimizedPrompt",
    "optimize",
    "WEIGHTS",
    "ScoreResult",
    "score_prompt",
    "TextStats",
    "analyze_text",
    "estimate_tokens",
]
