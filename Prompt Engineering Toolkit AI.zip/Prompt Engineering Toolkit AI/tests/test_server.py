"""Integration tests for the chat web server (promptforge.server).

These start a real server on an ephemeral port and make HTTP requests with the
standard library only, so the whole request/response path is exercised.
"""

from __future__ import annotations

import json
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer

from promptforge.server import _Handler


class ServerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
        cls.port = cls.httpd.server_address[1]
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls) -> None:
        cls.httpd.shutdown()
        cls.httpd.server_close()

    def _url(self, path: str) -> str:
        return f"http://127.0.0.1:{self.port}{path}"

    def _post(self, path: str, payload: dict) -> dict:
        req = urllib.request.Request(
            self._url(path),
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read())

    def test_index_serves_ui(self) -> None:
        with urllib.request.urlopen(self._url("/"), timeout=5) as resp:
            self.assertEqual(resp.status, 200)
            body = resp.read()
        self.assertIn(b"Prompt Engineering Toolkit", body)

    def test_health(self) -> None:
        with urllib.request.urlopen(self._url("/health"), timeout=5) as resp:
            data = json.loads(resp.read())
        self.assertEqual(data["status"], "ok")

    def test_chat_generate(self) -> None:
        data = self._post("/api/chat", {"message": "Write a prompt for a tweet", "history": []})
        self.assertIn("## Role", data["text"])
        self.assertEqual(data["kind"], "generate")

    def test_chat_greeting(self) -> None:
        data = self._post("/api/chat", {"message": "start", "history": []})
        self.assertEqual(data["kind"], "greeting")

    def test_unknown_route_404(self) -> None:
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            urllib.request.urlopen(self._url("/nope"), timeout=5)
        self.assertEqual(ctx.exception.code, 404)

    def test_invalid_json_400(self) -> None:
        req = urllib.request.Request(
            self._url("/api/chat"),
            data=b"not json",
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            urllib.request.urlopen(req, timeout=5)
        self.assertEqual(ctx.exception.code, 400)


if __name__ == "__main__":
    unittest.main()
