# Changelog

All notable changes to this project are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Planned
- Next.js web app: landing page, searchable library browser, and AI Playground.
- FastAPI service exposing the engine over HTTP.
- Grow the prompt library toward 1,000+ curated, categorised prompts.
- Prompt version control with a diff viewer.
- Semantic (embedding-based) search alongside keyword search.

## [0.1.0] - 2026-01

The first release: a complete, tested, dependency-free core engine.

### Added
- **Prompt schema** (`promptforge.schema`) with full validation.
- **Model registry** (`promptforge.models`) covering ChatGPT, Claude, Gemini,
  Grok, DeepSeek, Llama, Mistral, Qwen and Perplexity, with a comparison helper
  and indicative cost estimation.
- **Scoring engine** (`promptforge.analysis.scoring`) — a deterministic,
  10-dimension, 0-100 prompt score with a letter grade and prioritised
  improvement suggestions.
- **Optimizer** (`promptforge.analysis.optimizer`) — rewrites a prompt into a
  structured, higher-scoring form and reports every change with a before/after
  score.
- **Generator** (`promptforge.generator`) — builds an optimised prompt from a
  goal/industry/tone/style/length spec.
- **Templates** (`promptforge.templates`) — JSON / Markdown / YAML / XML / CSV
  renderers plus ready-made structured-output, tool-calling, function-calling
  and API-prompt scaffolds.
- **Prompt library** (`promptforge.library`) — loader, validator and keyword
  search with category/tag/difficulty/model filters; seeded with a curated
  starter set across 12 categories.
- **CLI** (`promptforge`) — `score`, `optimize`, `generate`, `search`,
  `models`, `template` and `validate` commands, all with `--json` output.
- Full unit-test suite (65 tests), CI workflow, and contributor tooling.

[Unreleased]: https://github.com/promptforge/promptforge/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/promptforge/promptforge/releases/tag/v0.1.0
