"""Lightweight, dependency-free text statistics for prompt analysis.

The scoring and optimizer modules need cheap, deterministic measurements of a
prompt's text: word/sentence counts, readability, vague-term density, and the
presence of structural cues (a role, an output format, reasoning instructions,
examples, and constraints).

Everything here is pure standard library so the analysis engine runs without any
installation step. The detection is heuristic by design — it powers a *linter*
for prompts, not a semantic model — which keeps it fast, explainable and fully
testable.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

# --- Lexicons -------------------------------------------------------------
# Vague qualifiers that weaken specificity. Kept lowercase; matched as words.
VAGUE_TERMS: frozenset[str] = frozenset(
    {
        "good", "nice", "great", "stuff", "things", "thing", "some", "several",
        "various", "appropriate", "relevant", "etc", "and so on", "better",
        "high quality", "high-quality", "as needed", "if necessary", "maybe",
        "kind of", "sort of", "a lot", "many", "few", "proper", "suitable",
    }
)

# Politeness / filler that adds tokens without changing model behaviour.
FILLER_TERMS: frozenset[str] = frozenset(
    {
        "please", "kindly", "i would like you to", "i want you to",
        "could you", "can you", "i need you to", "just", "really", "very",
        "actually", "basically", "simply", "in order to",
    }
)

# Phrases that indicate a role/persona has been assigned to the model.
ROLE_CUES = (
    "you are", "act as", "you act", "your role", "as an expert",
    "as a senior", "you're a", "you are a", "imagine you are", "behave as",
)

# Phrases that request an explicit output format / structure.
FORMAT_CUES = (
    "json", "yaml", "xml", "csv", "markdown", "table", "bullet", "numbered list",
    "output format", "respond in", "return a", "return the", "format:",
    "as a list", "in the following format", "schema", "headings",
)

# Phrases that elicit step-by-step / chain-of-thought reasoning.
REASONING_CUES = (
    "step by step", "step-by-step", "think through", "reason about",
    "explain your reasoning", "show your work", "chain of thought",
    "let's think", "lets think", "work through", "first.*then", "break it down",
    "before answering",
)

# Phrases that signal worked examples / few-shot demonstrations.
EXAMPLE_CUES = (
    "example", "e.g.", "for instance", "for example", "few-shot", "few shot",
    "input:", "output:", "sample", "demonstration", "such as",
)

# Phrases that impose constraints / guardrails (reduce output variance).
CONSTRAINT_CUES = (
    "must", "must not", "do not", "don't", "only", "no more than",
    "at least", "limit", "constraint", "rules:", "requirements:", "avoid",
    "never", "always", "exactly", "maximum", "minimum", "within",
)

# Phrases that provide background/context for the task.
CONTEXT_CUES = (
    "context:", "background:", "given", "we are", "our company", "the goal is",
    "you have", "the user", "assume", "scenario", "here is", "here's",
)

_WORD_RE = re.compile(r"[A-Za-z0-9']+")
# A pragmatic sentence splitter: terminal punctuation or newlines.
_SENTENCE_RE = re.compile(r"[^.!?\n]+[.!?]?")
_VOWEL_GROUPS_RE = re.compile(r"[aeiouy]+", re.IGNORECASE)


def _count_phrases(haystack: str, needles: tuple[str, ...]) -> int:
    """Count how many of ``needles`` appear in ``haystack``.

    ``needles`` may contain a simple ``.*`` wildcard (used for cues such as
    ``"first.*then"``) which is interpreted as a regex; everything else is a
    plain case-insensitive substring search.
    """
    count = 0
    for needle in needles:
        if ".*" in needle:
            if re.search(needle, haystack, re.IGNORECASE | re.DOTALL):
                count += 1
        elif needle in haystack:
            count += 1
    return count


def _estimate_syllables(word: str) -> int:
    """Roughly estimate the syllable count of a word (vowel-group heuristic)."""
    groups = _VOWEL_GROUPS_RE.findall(word)
    syllables = len(groups)
    # Silent trailing 'e' rarely forms its own syllable.
    if word.endswith("e") and syllables > 1:
        syllables -= 1
    return max(syllables, 1)


@dataclass(slots=True)
class TextStats:
    """Computed statistics for a single prompt string.

    All counts are derived once in :func:`analyze_text` and reused by every
    metric so analysis stays O(n) in the prompt length.
    """

    text: str
    char_count: int
    word_count: int
    sentence_count: int
    avg_sentence_len: float
    avg_word_len: float
    flesch_reading_ease: float
    vague_count: int
    filler_count: int
    has_role: bool
    has_format: bool
    has_reasoning: bool
    has_examples: bool
    constraint_count: int
    has_context: bool
    estimated_tokens: int
    # Raw cue hit-counts, useful for the optimizer and debugging.
    cue_hits: dict[str, int] = field(default_factory=dict)


def estimate_tokens(text: str) -> int:
    """Estimate token count without a tokenizer.

    Uses the widely-cited ~4-characters-per-token approximation, blended with a
    word-count floor so very short or whitespace-heavy prompts are not
    underestimated. This is intentionally provider-agnostic; exact counts vary
    per tokenizer.
    """
    words = len(_WORD_RE.findall(text))
    char_estimate = len(text) / 4
    return max(1, round((char_estimate + words * 1.3) / 2))


def analyze_text(text: str) -> TextStats:
    """Compute :class:`TextStats` for ``text``.

    The function never raises on unusual input (empty string, no punctuation,
    emoji, etc.); it falls back to safe defaults so downstream scoring is robust.
    """
    lowered = text.lower()
    words = _WORD_RE.findall(text)
    word_count = len(words)
    sentences = [s.strip() for s in _SENTENCE_RE.findall(text) if s.strip()]
    sentence_count = max(len(sentences), 1)

    avg_sentence_len = word_count / sentence_count if word_count else 0.0
    avg_word_len = (
        sum(len(w) for w in words) / word_count if word_count else 0.0
    )

    # Flesch Reading Ease — higher is easier. Clamped to a sane range.
    syllables = sum(_estimate_syllables(w) for w in words) or 1
    if word_count:
        flesch = (
            206.835
            - 1.015 * (word_count / sentence_count)
            - 84.6 * (syllables / word_count)
        )
    else:
        flesch = 0.0
    flesch = max(0.0, min(100.0, flesch))

    vague_count = _count_phrases(lowered, tuple(VAGUE_TERMS))
    filler_count = _count_phrases(lowered, tuple(FILLER_TERMS))

    cue_hits = {
        "role": _count_phrases(lowered, ROLE_CUES),
        "format": _count_phrases(lowered, FORMAT_CUES),
        "reasoning": _count_phrases(lowered, REASONING_CUES),
        "examples": _count_phrases(lowered, EXAMPLE_CUES),
        "constraints": _count_phrases(lowered, CONSTRAINT_CUES),
        "context": _count_phrases(lowered, CONTEXT_CUES),
    }

    return TextStats(
        text=text,
        char_count=len(text),
        word_count=word_count,
        sentence_count=sentence_count,
        avg_sentence_len=round(avg_sentence_len, 2),
        avg_word_len=round(avg_word_len, 2),
        flesch_reading_ease=round(flesch, 2),
        vague_count=vague_count,
        filler_count=filler_count,
        has_role=cue_hits["role"] > 0,
        has_format=cue_hits["format"] > 0,
        has_reasoning=cue_hits["reasoning"] > 0,
        has_examples=cue_hits["examples"] > 0,
        constraint_count=cue_hits["constraints"],
        has_context=cue_hits["context"] > 0,
        estimated_tokens=estimate_tokens(text),
        cue_hits=cue_hits,
    )
