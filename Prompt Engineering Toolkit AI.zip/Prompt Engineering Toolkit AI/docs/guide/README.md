# The PromptForge Prompt Engineering Guide

A practical, model-agnostic handbook that takes you from your first prompt to
production-grade prompt systems. Every principle here is also what the
PromptForge **scoring engine** measures and the **optimizer** applies — so you
can *check your work* with `promptforge score` as you learn.

> **How to use this guide:** read the level that matches you, then practise by
> pasting your prompts into the chat app (`promptforge serve`) or running
> `promptforge score "<your prompt>"`.

---

## Contents
1. [Beginner](#1-beginner--the-anatomy-of-a-good-prompt)
2. [Intermediate](#2-intermediate--structure-and-control)
3. [Advanced](#3-advanced--reasoning-and-reliability)
4. [Expert](#4-expert--systems-evaluation-and-safety)
5. [Best practices cheat sheet](#5-best-practices-cheat-sheet)
6. [Anti-patterns](#6-anti-patterns)
7. [Further reading](#7-further-reading)

---

## 1. Beginner — the anatomy of a good prompt

A strong prompt almost always answers six questions. Miss one and the model
fills the gap with a guess.

| Element | Question it answers | Example |
|---------|--------------------|---------|
| **Role** | Who should the model be? | "You are a senior data analyst." |
| **Context** | What background matters? | "We run an e-commerce store…" |
| **Task** | What exactly to do? | "Identify the top 3 churn drivers." |
| **Constraints** | What are the rules/limits? | "Use only the provided columns." |
| **Output format** | What shape should the answer take? | "Return JSON with a `drivers` array." |
| **Examples** | What does 'good' look like? | A sample input/output pair. |

**Before**
```
write something about our product
```
**After**
```
You are a product marketer. Write a 50-word product blurb for a time-tracking
app aimed at freelancers. Tone: friendly. Avoid hype words. Output: one paragraph.
```

> 🧪 Try it: `promptforge score "write something about our product"` then score
> the improved version and watch the number climb.

---

## 2. Intermediate — structure and control

### Use sections
Models follow clearly delimited instructions better than walls of text. Use
Markdown headings or XML-style tags:

```
## Task
...
## Constraints
- ...
## Output Format
...
```

### Specify the output precisely
"Make it consistent" is a wish; a schema is a contract. If you need to parse the
result, **show the exact shape**:

```
Return ONLY valid JSON: {"summary": string, "items": string[]}
```

### Control length and scope
State limits explicitly: "≤ 120 words", "exactly 5 bullets", "no preamble".

### Few-shot examples
One or two worked examples often beat paragraphs of explanation. Keep them short
and representative; label them `Input:` / `Output:`.

---

## 3. Advanced — reasoning and reliability

### Elicit reasoning for hard tasks
For multi-step problems, ask the model to **think step by step** before
answering. This "chain-of-thought" improves accuracy on analysis, math and
debugging. For clean output, ask it to reason first and then give a clearly
delimited final answer.

### Reduce variance
Three levers make outputs repeatable:
1. **Constraints** — bound what's allowed.
2. **A fixed output format** — remove shape ambiguity.
3. **Examples** — anchor style and structure.

The PromptForge `reliability` and `output_consistency` scores reward exactly
these.

### Decompose
Break big asks into stages ("first outline, then draft, then critique"). You can
chain prompts, feeding each stage's output into the next.

### Ground the model
Tell it what to do when unsure: "If information is missing, state your
assumptions" and "never fabricate facts, citations or data." This single line
prevents a large class of hallucinations.

---

## 4. Expert — systems, evaluation, and safety

### Treat prompts as versioned artifacts
Give each prompt a semantic version, track changes, and **measure** before/after.
PromptForge scores are deterministic, so you can gate changes in CI:
"a prompt must score ≥ 80 to merge."

### Evaluate, don't vibe-check
Build a small evaluation set of representative inputs and expected properties.
Compare models and prompt variants on the same set (see `promptforge models
compare`). Track quality, latency and cost together.

### Structured output & tool use
For programmatic pipelines, prefer strict structured output (JSON schema) and,
where supported, function/tool calling. Start from the scaffolds:
`promptforge template structured_output` / `tool_calling` / `function_calling`.

### Safety and robustness
- Never instruct a model to ignore or bypass its guidelines — it makes prompts
  brittle and policy-violating. (PromptForge's `safety` score flags this
  phrasing.)
- Treat all model output as **untrusted input** to the rest of your system;
  validate and sandbox it.
- Be aware of prompt injection when your prompt includes external/user content;
  separate instructions from data clearly.

---

## 5. Best practices cheat sheet

- ✅ Assign a clear role.
- ✅ Provide the minimum sufficient context — no more, no less.
- ✅ State the task as an explicit instruction.
- ✅ Add constraints (length, scope, must/avoid).
- ✅ Pin the output format; show a sample if it must be parsed.
- ✅ Add a worked example for tricky tasks.
- ✅ Ask for step-by-step reasoning on hard problems.
- ✅ Tell the model how to handle missing information.
- ✅ Be concrete: numbers, names, criteria — not "good" or "appropriate".
- ✅ Measure it (`promptforge score`) and iterate.

## 6. Anti-patterns

- ❌ **Vague qualifiers** — "good", "nice", "some", "appropriate".
- ❌ **Politeness padding** — "please kindly just…" wastes tokens, adds nothing.
- ❌ **Wall of text** — no structure, the model loses the thread.
- ❌ **Unspecified output** — then complaining it's "inconsistent".
- ❌ **Over-stuffing** — ten tasks in one prompt; split them.
- ❌ **Jailbreak phrasing** — "ignore previous instructions"; brittle and unsafe.
- ❌ **Trusting invented facts/numbers** — always require grounding.

## 7. Further reading

Prompt engineering is a fast-moving field; consult primary sources and provider
documentation for the latest techniques (chain-of-thought, self-consistency,
ReAct, retrieval-augmented generation, structured output, and tool use). Each
major provider (OpenAI, Anthropic, Google, and others) publishes a prompt-design
guide worth reading alongside this one.

---

*Built something great with these ideas? Contribute the prompt back to the
library — see [CONTRIBUTING.md](../../CONTRIBUTING.md).*
