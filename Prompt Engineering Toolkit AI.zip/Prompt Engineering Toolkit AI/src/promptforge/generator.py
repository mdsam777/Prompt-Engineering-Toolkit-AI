"""The Prompt Generator.

Turns a small, structured :class:`GeneratorSpec` (goal, industry, tone, output
style, target model, length, language, audience) into a complete, best-practice
prompt — then scores it so the caller can see the quality up front.

The generator is fully deterministic and offline: it assembles the prompt from
documented building blocks rather than calling an LLM, so it works in CI, tests
and air-gapped environments. The output deliberately follows the same structured
layout the optimizer produces (Role / Context / Task / Constraints / Output
Format / Reasoning), giving users a consistent house style.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .analysis.optimizer import infer_role
from .analysis.scoring import ScoreResult, score_prompt

#: Supported length presets mapped to a target word budget and a detail hint.
LENGTH_PRESETS: dict[str, tuple[int, str]] = {
    "short": (120, "Be concise — a few tight sentences."),
    "medium": (300, "Provide a thorough but focused response."),
    "long": (700, "Provide a comprehensive, well-structured response."),
}


@dataclass(slots=True)
class GeneratorSpec:
    """User-supplied parameters that shape the generated prompt.

    Attributes:
        goal: What the user wants the model to achieve (required).
        industry: Domain/vertical (e.g. ``"finance"``). Informs the role.
        output_style: Desired output format (e.g. ``"Markdown"``, ``"JSON"``).
        tone: Voice of the response (e.g. ``"professional"``, ``"friendly"``).
        model: Target model id, or ``"all"`` for provider-agnostic.
        length: One of :data:`LENGTH_PRESETS` keys.
        language: Natural language for the response.
        audience: Who the response is for.
    """

    goal: str
    industry: str = "general"
    output_style: str = "Markdown"
    tone: str = "professional"
    model: str = "all"
    length: str = "medium"
    language: str = "English"
    audience: str = "a general audience"


@dataclass(slots=True)
class GeneratedPrompt:
    """A generated prompt plus its quality score."""

    spec: GeneratorSpec
    prompt: str
    score: ScoreResult | None = None
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, object]:
        """Serialise to a JSON-ready ``dict``."""
        return {
            "prompt": self.prompt,
            "score": self.score.to_dict() if self.score else None,
            "notes": self.notes,
        }


def generate(spec: GeneratorSpec) -> GeneratedPrompt:
    """Generate an optimised prompt from ``spec``.

    Args:
        spec: The generation parameters.

    Returns:
        A :class:`GeneratedPrompt` with the assembled text and its score.

    Raises:
        ValueError: if ``spec.goal`` is empty or ``spec.length`` is unknown.
    """
    if not spec.goal.strip():
        raise ValueError("GeneratorSpec.goal must not be empty")
    if spec.length not in LENGTH_PRESETS:
        valid = ", ".join(LENGTH_PRESETS)
        raise ValueError(f"unknown length {spec.length!r}; expected: {valid}")

    word_budget, detail_hint = LENGTH_PRESETS[spec.length]
    # Derive the expert role from the combined goal + industry signal.
    role = infer_role(f"{spec.goal} {spec.industry}")
    notes: list[str] = []

    industry_clause = (
        f" working in the {spec.industry} domain"
        if spec.industry and spec.industry.lower() != "general"
        else ""
    )

    sections = [
        f"## Role\nYou are {role}{industry_clause}.",
        (
            "## Context\n"
            f"You are assisting {spec.audience}. "
            f"Adopt a {spec.tone} tone and respond in {spec.language}."
        ),
        f"## Task\n{spec.goal.strip()}",
        (
            "## Constraints\n"
            f"- {detail_hint} Aim for roughly {word_budget} words.\n"
            "- Ground every claim in the provided context; state assumptions "
            "explicitly and never fabricate facts or sources.\n"
            "- Stay strictly on task and within scope."
        ),
        f"## Output Format\nRespond in {spec.output_style}.",
        (
            "## Reasoning\n"
            "Think through the problem step by step, then present the final "
            "answer clearly."
        ),
    ]

    if spec.model and spec.model.lower() != "all":
        notes.append(f"Tuned for model: {spec.model}.")

    prompt = "\n\n".join(sections).strip()
    return GeneratedPrompt(
        spec=spec,
        prompt=prompt,
        score=score_prompt(prompt),
        notes=notes,
    )
