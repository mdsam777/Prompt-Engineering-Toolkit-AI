#!/usr/bin/env python3
"""Clickable launcher for the Prompt Engineering Toolkit chat app.

Double-click ``start.bat`` (Windows), ``start.command`` (macOS), or run
``python start.py`` from anywhere. This works straight from a fresh checkout —
no installation step required — by putting the bundled ``src/`` package on the
import path and starting the local web server, which opens your browser.
"""

from __future__ import annotations

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "src")
if SRC not in sys.path:
    sys.path.insert(0, SRC)


def _main() -> int:
    if sys.version_info < (3, 10):
        print("Python 3.10 or newer is required. You have", sys.version.split()[0])
        return 1
    try:
        from promptforge.server import serve
    except Exception as exc:  # pragma: no cover - defensive, helps non-technical users
        print("Could not start the toolkit:", exc)
        print("Make sure you launched this from inside the project folder.")
        return 1
    serve()
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
