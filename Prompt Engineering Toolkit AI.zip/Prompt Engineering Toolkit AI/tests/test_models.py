"""Tests for the model registry (promptforge.models)."""

from __future__ import annotations

import unittest

from promptforge.models import compare, get_model, is_known_model, list_models


class ModelTests(unittest.TestCase):
    def test_registry_includes_major_families(self) -> None:
        ids = {m.id for m in list_models()}
        for expected in ("gpt", "claude", "gemini", "grok", "deepseek",
                         "llama", "mistral", "qwen", "perplexity"):
            self.assertIn(expected, ids)

    def test_get_model_case_insensitive(self) -> None:
        self.assertEqual(get_model("GPT").id, "gpt")

    def test_get_unknown_model_raises(self) -> None:
        with self.assertRaises(KeyError):
            get_model("does-not-exist")

    def test_is_known_model_handles_wildcard(self) -> None:
        self.assertTrue(is_known_model("all"))
        self.assertTrue(is_known_model("claude"))
        self.assertFalse(is_known_model("nope"))

    def test_estimate_cost(self) -> None:
        gpt = get_model("gpt")
        # 1M input + 1M output should equal the sum of the per-Mtok prices.
        expected = gpt.input_cost_per_mtok + gpt.output_cost_per_mtok
        self.assertAlmostEqual(gpt.estimate_cost(1_000_000, 1_000_000), expected, places=6)

    def test_compare_returns_rows(self) -> None:
        table = compare(["gpt", "claude"])
        self.assertEqual(set(table), {"gpt", "claude"})
        for row in table.values():
            self.assertIn("coding", row)
            self.assertIn("context_window", row)


if __name__ == "__main__":
    unittest.main()
