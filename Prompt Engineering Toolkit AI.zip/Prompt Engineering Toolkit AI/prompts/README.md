# The Prompt Library

This folder is the data behind PromptForge's searchable prompt library. Prompts
are plain JSON so anyone — not just developers — can contribute, and so the
library stays diff-friendly and version-controllable.

```
prompts/
├── schema/
│   └── prompt.schema.json     # JSON Schema every prompt must satisfy
└── data/
    └── <category>/*.json      # one array of prompts per file
```

## Adding a prompt

1. Find or create `prompts/data/<category>/<category>.json`.
2. Append a prompt object to the array (one concept per prompt).
3. Fill in **every** required field (see the table in
   [CONTRIBUTING.md](../CONTRIBUTING.md#-add-a-prompt-to-the-library)).
4. Validate:

   ```bash
   promptforge validate
   # or, dependency-free:
   PYTHONPATH=src python -m promptforge.cli validate
   ```

5. Open a PR. CI re-validates automatically.

## Minimal example

```json
{
  "id": "my-prompt-slug",
  "title": "My Prompt",
  "description": "What it does, in one or two sentences (≤ 280 chars).",
  "category": "programming",
  "difficulty": "beginner",
  "body": "## Role\nYou are ...\n\n## Task\nDo X with {input}.",
  "expected_output": "What a good response looks like.",
  "supported_models": ["all"],
  "example": "A concrete, filled-in example.",
  "best_practices": ["Be specific."],
  "common_mistakes": ["Being vague."],
  "version": "1.0.0",
  "tags": ["example", "starter"],
  "related_prompts": []
}
```

## Quality bar

Aim for prompts that would score well in `promptforge score`: a clear role,
sufficient context, explicit constraints, and a defined output format. See the
[Prompt Engineering Guide](../docs/guide/README.md).

## Categories

The starter library spans: programming · marketing · seo · data-analysis ·
business · content-creation · email · research · education · resume ·
translation · trading — and is growing toward **1,000+** community prompts.
New categories are welcome; just add a new folder.
