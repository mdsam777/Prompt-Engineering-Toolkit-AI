"""The Prompt Optimizer.

Takes a raw prompt and rewrites it into a structured, best-practice form:
a clear role, supporting context, the preserved task, explicit constraints, an
output-format specification and (for non-trivial tasks) a reasoning instruction.
Filler and politeness padding are stripped from the user's task text.

The optimizer is deterministic and self-validating: it scores the prompt before
and after, and reports the delta. In practice the rewrite raises the overall
score because it fills the structural gaps the scoring engine measures.

The transformation is *additive and transparent* — every change is recorded in
``OptimizedPrompt.changes`` so the user understands exactly what happened and can
accept or tweak individual edits.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from .scoring import ScoreResult, score_prompt
from .text_stats import FILLER_TERMS, analyze_text

# Map intent keywords to a sensible expert role. First match wins, so order from
# most-specific to least. Used only when the prompt has no role of its own.
_ROLE_RULES: list[tuple[tuple[str, ...], str]] = [
    (("code", "function", "bug", "refactor", "python", "javascript", "api",
      "sql", "docker", "regex", "algorithm"), "a senior software engineer"),
    (("marketing", "campaign", "brand", "ad copy", "audience", "funnel"),
     "a senior marketing strategist"),
    (("seo", "keyword", "serp", "backlink", "meta description"),
     "an SEO specialist"),
    (("email", "outreach", "cold email", "newsletter"), "an expert copywriter"),
    (("resume", "cv", "cover letter", "interview"), "a professional career coach"),
    (("trading", "forex", "stock", "market", "indicator", "backtest"),
     "a quantitative trading analyst"),
    (("finance", "budget", "valuation", "accounting", "invoice"),
     "a financial analyst"),
    (("data", "dataset", "analysis", "statistics", "chart", "excel"),
     "a senior data analyst"),
    (("research", "paper", "literature", "summarize", "summarise"),
     "a meticulous research assistant"),
    (("translate", "translation", "localize", "localise"),
     "a professional translator"),
    (("teach", "explain", "lesson", "student", "tutorial"),
     "an experienced educator"),
    (("story", "poem", "creative", "screenplay", "novel"),
     "a creative writer"),
]

# Words whose presence suggests the task is non-trivial and benefits from an
# explicit reasoning step.
_COMPLEX_CUES = (
    "analy", "compare", "design", "plan", "strategy", "optimize", "optimise",
    "debug", "evaluate", "decide", "recommend", "diagnose", "architect",
    "calculate", "derive", "prove", "trade-off", "tradeoff",
)

_FILLER_RE = re.compile(
    r"\b(" + "|".join(re.escape(t) for t in sorted(FILLER_TERMS, key=len, reverse=True)) + r")\b",
    re.IGNORECASE,
)


@dataclass(slots=True)
class OptimizedPrompt:
    """Result of optimising a prompt.

    Attributes:
        original: The prompt as supplied.
        improved: The rewritten, structured prompt.
        changes: Human-readable description of every edit applied.
        before: Score of the original prompt.
        after: Score of the improved prompt.
    """

    original: str
    improved: str
    changes: list[str] = field(default_factory=list)
    before: ScoreResult | None = None
    after: ScoreResult | None = None

    @property
    def delta(self) -> float:
        """Overall score improvement (``after - before``), rounded to 1 dp."""
        if self.before is None or self.after is None:
            return 0.0
        return round(self.after.overall - self.before.overall, 1)

    def to_dict(self) -> dict[str, object]:
        """Serialise to a JSON-ready ``dict``."""
        return {
            "original": self.original,
            "improved": self.improved,
            "changes": self.changes,
            "before": self.before.to_dict() if self.before else None,
            "after": self.after.to_dict() if self.after else None,
            "delta": self.delta,
        }


def infer_role(text: str) -> str:
    """Pick an expert role that matches the text's apparent intent.

    Shared with the generator so role inference is consistent across the toolkit.
    Falls back to a generic expert role when no keyword matches.
    """
    lowered = text.lower()
    for keywords, role in _ROLE_RULES:
        if any(k in lowered for k in keywords):
            return role
    return "an expert assistant"


def _strip_filler(text: str) -> tuple[str, int]:
    """Remove filler/politeness phrases. Returns ``(clean_text, removed_count)``."""
    removed = len(_FILLER_RE.findall(text))
    if not removed:
        return text.strip(), 0
    cleaned = _FILLER_RE.sub("", text)
    # Collapse the whitespace left behind and tidy capitalisation.
    cleaned = re.sub(r"\s{2,}", " ", cleaned).strip()
    cleaned = re.sub(r"\s+([,.;:])", r"\1", cleaned)
    if cleaned:
        cleaned = cleaned[0].upper() + cleaned[1:]
    return cleaned, removed


def _looks_complex(text: str) -> bool:
    """Heuristically decide whether the task warrants explicit reasoning."""
    lowered = text.lower()
    return any(cue in lowered for cue in _COMPLEX_CUES) or len(text.split()) > 40


def optimize(
    prompt: str,
    *,
    output_format: str | None = None,
    add_reasoning: bool | None = None,
) -> OptimizedPrompt:
    """Rewrite ``prompt`` into a structured, higher-scoring form.

    Args:
        prompt: The raw prompt to improve.
        output_format: Desired output format (e.g. ``"Markdown"``, ``"JSON"``).
            If ``None`` a sensible default instruction is used.
        add_reasoning: Force-on/force-off the reasoning section. When ``None``
            the optimizer decides based on apparent task complexity.

    Returns:
        An :class:`OptimizedPrompt` with the rewrite and a before/after score.
    """
    original = prompt
    before = score_prompt(original)
    stats = before.stats or analyze_text(original)
    changes: list[str] = []

    task_text, removed = _strip_filler(original)
    if removed:
        changes.append(f"Removed {removed} filler/politeness phrase(s).")
    if not task_text:
        task_text = original.strip() or "Describe the task here."

    sections: list[str] = []

    # 1. Role -----------------------------------------------------------------
    if stats.has_role:
        changes.append("Kept the existing role definition.")
    else:
        role = infer_role(original)
        sections.append(f"## Role\nYou are {role}.")
        changes.append(f"Added an explicit role: '{role}'.")

    # 2. Context --------------------------------------------------------------
    if not stats.has_context:
        sections.append(
            "## Context\n"
            "Background: <add the relevant facts, audience and goal here so the "
            "model has the context it needs>."
        )
        changes.append("Added a Context section scaffold for background/goal.")

    # 3. Task (always present, cleaned) --------------------------------------
    sections.append(f"## Task\n{task_text}")

    # 4. Constraints ----------------------------------------------------------
    if stats.constraint_count == 0:
        sections.append(
            "## Constraints\n"
            "- Stay strictly on topic and within scope.\n"
            "- If information is missing, state your assumptions explicitly.\n"
            "- Do not fabricate facts, citations or data."
        )
        changes.append("Added a Constraints section with safe defaults.")

    # 5. Output format --------------------------------------------------------
    if not stats.has_format:
        fmt = output_format or "Markdown with clear headings and bullet points"
        sections.append(f"## Output Format\nRespond in {fmt}.")
        changes.append(f"Specified the output format ({fmt}).")

    # 6. Reasoning ------------------------------------------------------------
    want_reasoning = _looks_complex(original) if add_reasoning is None else add_reasoning
    if want_reasoning and not stats.has_reasoning:
        sections.append(
            "## Reasoning\n"
            "Think step by step and briefly explain the key decisions before "
            "giving the final answer."
        )
        changes.append("Added a step-by-step reasoning instruction.")

    improved = "\n\n".join(sections).strip()
    after = score_prompt(improved)

    if not changes:
        changes.append("Prompt already follows best practices; no changes needed.")

    return OptimizedPrompt(
        original=original,
        improved=improved,
        changes=changes,
        before=before,
        after=after,
    )
