"""Smoke tests for the CLI (promptforge.cli)."""

from __future__ import annotations

import contextlib
import io
import json
import unittest

from promptforge.cli import main


def run(argv: list[str]) -> tuple[int, str]:
    """Run the CLI capturing stdout. Returns ``(exit_code, output)``."""
    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer):
        code = main(argv)
    return code, buffer.getvalue()


class CliTests(unittest.TestCase):
    def test_score_text(self) -> None:
        code, out = run(["score", "write code"])
        self.assertEqual(code, 0)
        self.assertIn("Overall", out)

    def test_score_json(self) -> None:
        code, out = run(["score", "write code", "--json"])
        self.assertEqual(code, 0)
        self.assertIn("overall", json.loads(out))

    def test_optimize(self) -> None:
        code, out = run(["optimize", "summarize this"])
        self.assertEqual(code, 0)
        self.assertIn("Improved prompt", out)

    def test_generate(self) -> None:
        code, out = run(["generate", "--goal", "Explain CTEs", "--length", "short"])
        self.assertEqual(code, 0)
        self.assertIn("## Role", out)

    def test_search_json(self) -> None:
        code, out = run(["search", "sql", "--json"])
        self.assertEqual(code, 0)
        ids = [row["id"] for row in json.loads(out)]
        self.assertIn("sql-query-builder", ids)

    def test_models_compare(self) -> None:
        code, out = run(["models", "compare", "gpt", "claude"])
        self.assertEqual(code, 0)
        self.assertIn("gpt", out)

    def test_template(self) -> None:
        code, out = run(["template", "structured_output", "--task", "extract names"])
        self.assertEqual(code, 0)
        self.assertIn("extract names", out)

    def test_validate(self) -> None:
        code, out = run(["validate"])
        self.assertEqual(code, 0)
        self.assertIn("OK", out)


if __name__ == "__main__":
    unittest.main()
