# Architecture

PromptForge is built around one principle: **a small, pure, well-tested core
engine, with thin interfaces layered on top.** The engine has zero runtime
dependencies and never touches the network, which makes it portable, fast,
deterministic, and trivial to test or embed.

```
┌─────────────────────────────────────────────────────────────┐
│                        Interfaces                            │
│  CLI (cli.py)   Chat app (server.py + web/)   [future: API]  │
└───────────────┬───────────────┬──────────────────────────────┘
                │               │
                ▼               ▼
        ┌───────────────────────────────────┐
        │        assistant.py (router)       │  ← natural-language intent
        └───────────────┬───────────────────┘
                        ▼
   ┌──────────────────────────────────────────────────────┐
   │                    Core engine                        │
   │                                                       │
   │  analysis/      generator.py   templates.py           │
   │   ├ text_stats  models.py      library.py             │
   │   ├ metrics     schema.py                             │
   │   ├ scoring                                           │
   │   └ optimizer                                         │
   └──────────────────────────────────────────────────────┘
                        ▼
        ┌───────────────────────────────────┐
        │   Data:  prompts/data/*.json       │
        │   Schema: prompts/schema/*.json    │
        └───────────────────────────────────┘
```

## Layers

### 1. Data
Prompts are plain JSON files under `prompts/data/<category>/`, validated against
`prompts/schema/prompt.schema.json`. Keeping data as files (not code) means
non-developers can contribute, and the library is diff-friendly and
version-controllable.

### 2. Core engine (`src/promptforge/`)
Pure-Python, dependency-free, fully typed modules:

| Module | Responsibility |
|--------|----------------|
| `schema.py` | The `Prompt` model + validation |
| `models.py` | Model registry + comparison + cost estimates |
| `analysis/text_stats.py` | Deterministic text measurements (one O(n) pass) |
| `analysis/metrics.py` | Ten per-dimension analyzers |
| `analysis/scoring.py` | Weighted 0–100 scoring engine |
| `analysis/optimizer.py` | Structured prompt rewriter |
| `generator.py` | Spec → optimised prompt |
| `templates.py` | JSON/MD/YAML/XML/CSV renderers + scaffolds |
| `library.py` | Load / validate / search the prompt collection |

**Why rule-based, not an LLM?** The scoring and optimisation are deterministic
static analysis. That makes them free, instant, private, reproducible, and
usable as a CI quality gate. (A real-LLM backend can be layered in later behind
the same interfaces without changing the core.)

### 3. Router (`assistant.py`)
Translates a free-text chat message into one of the engine operations
(generate / optimize / score / search / show) and formats a Markdown reply with
quick-reply suggestions. This is the only "conversational" layer and it is
stateless — conversation history is passed in by the caller.

### 4. Interfaces
- **CLI** (`cli.py`) — argparse subcommands, `--json` everywhere.
- **Chat app** (`server.py` + `web/index.html`) — a stdlib HTTP server that
  serves a single-page UI and answers `POST /api/chat` via the router.
- **Launchers** (`start.bat`, `start.command`, `start.py`) — zero-config entry
  points that put `src/` on the path and start the server.

## Design rules

1. **Zero runtime dependencies in the core.** New deps need strong justification.
2. **Determinism.** Same input → same output. No hidden state, no clocks, no RNG.
3. **Provider-agnostic.** Model specifics live only in `models.py`.
4. **Fail soft at the edges.** Validation returns problem lists rather than
   raising; the server always returns a reply even on internal error.
5. **Everything is tested.** See `tests/` — 80+ unit and integration tests run on
   the standard library alone.

## Testing strategy

- **Unit tests** for each engine module (schema, models, scoring, optimizer,
  generator, templates, library).
- **Data-integrity tests** (`test_prompts_valid.py`) that fail CI if a
  contributed prompt is malformed or references a missing related prompt.
- **Integration tests** (`test_server.py`) that start a real HTTP server and
  exercise the full request path.

Run everything with `pytest`, or dependency-free with
`PYTHONPATH=src python -m unittest discover -s tests`.
