#!/bin/bash
# Prompt Engineering Toolkit - one-click launcher (macOS / Linux)
# On macOS you can double-click this file. On Linux: run ./start.command
# (You may need to make it executable once: chmod +x start.command)
cd "$(dirname "$0")" || exit 1
echo "Starting the Prompt Engineering Toolkit..."
if command -v python3 >/dev/null 2>&1; then
  python3 start.py
elif command -v python >/dev/null 2>&1; then
  python start.py
else
  echo "Python 3.10+ was not found. Install it from https://www.python.org/downloads/"
  read -r -p "Press Enter to close..."
fi
