"""Tests for the prompt library loader and search (promptforge.library)."""

from __future__ import annotations

import unittest

from promptforge.library import PromptLibrary
from promptforge.schema import Difficulty


class LibraryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        # Loads the real on-disk library from the default repo data directory.
        cls.lib = PromptLibrary.load()

    def test_library_is_not_empty(self) -> None:
        self.assertGreater(len(self.lib), 0)

    def test_get_known_prompt(self) -> None:
        prompt = self.lib.get("sql-query-builder")
        self.assertIsNotNone(prompt)
        self.assertEqual(prompt.category, "data-analysis")

    def test_get_unknown_returns_none(self) -> None:
        self.assertIsNone(self.lib.get("does-not-exist"))

    def test_keyword_search(self) -> None:
        hits = self.lib.search("sql")
        ids = [h.prompt.id for h in hits]
        self.assertIn("sql-query-builder", ids)

    def test_category_filter(self) -> None:
        hits = self.lib.search("", category="seo")
        self.assertTrue(hits)
        self.assertTrue(all(h.prompt.category == "seo" for h in hits))

    def test_difficulty_filter(self) -> None:
        hits = self.lib.search("", difficulty=Difficulty.ADVANCED)
        self.assertTrue(all(h.prompt.difficulty == Difficulty.ADVANCED for h in hits))

    def test_tag_filter(self) -> None:
        hits = self.lib.search("", tags=["debugging"])
        self.assertTrue(all("debugging" in h.prompt.tags for h in hits))

    def test_limit(self) -> None:
        self.assertLessEqual(len(self.lib.search("", limit=2)), 2)

    def test_categories_and_tags(self) -> None:
        self.assertTrue(self.lib.categories())
        self.assertTrue(self.lib.tags())


if __name__ == "__main__":
    unittest.main()
