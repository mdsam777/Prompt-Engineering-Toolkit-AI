<!-- Thanks for contributing to PromptForge! Please complete the checklist. -->

## What does this PR do?

<!-- A concise description of the change and the motivation behind it. -->

## Type of change

- [ ] 🐛 Bug fix
- [ ] ✨ New feature
- [ ] 📝 New prompt(s)
- [ ] 📖 Documentation
- [ ] ♻️ Refactor / chore

## Related issues

<!-- e.g. Closes #123 -->

## Checklist

- [ ] I read the [Contributing Guide](../CONTRIBUTING.md).
- [ ] My code follows the project style (`ruff check` passes).
- [ ] I added or updated tests where relevant (`pytest` passes).
- [ ] If I added prompts, `promptforge validate` passes locally.
- [ ] I updated documentation where relevant.

## Screenshots / output (optional)

<!-- For UI or CLI output changes, paste a screenshot or terminal capture. -->
