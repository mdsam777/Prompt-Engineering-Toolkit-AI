"""Tests for the template renderers (promptforge.templates)."""

from __future__ import annotations

import json
import unittest

from promptforge.templates import get_template, render, to_csv, to_xml, to_yaml

SAMPLE = {
    "role": "expert",
    "tags": ["a", "b"],
    "meta": {"version": "1.0.0", "lang": "en"},
}


class TemplateTests(unittest.TestCase):
    def test_json_round_trip(self) -> None:
        out = render(SAMPLE, "json")
        self.assertEqual(json.loads(out), SAMPLE)

    def test_yaml_contains_keys_and_list(self) -> None:
        out = to_yaml(SAMPLE)
        self.assertIn("role: expert", out)
        self.assertIn("- a", out)
        self.assertIn("version: 1.0.0", out)

    def test_xml_well_formed(self) -> None:
        import xml.dom.minidom as minidom

        out = to_xml(SAMPLE)
        # Will raise if the XML is malformed.
        minidom.parseString(out)
        self.assertIn("<role>expert</role>", out)

    def test_csv_key_value(self) -> None:
        out = to_csv({"a": 1, "b": 2})
        self.assertIn("key,value", out)
        self.assertIn("a,1", out)

    def test_csv_table(self) -> None:
        out = to_csv([{"x": 1, "y": 2}, {"x": 3, "y": 4}])
        lines = out.splitlines()
        self.assertEqual(lines[0], "x,y")
        self.assertEqual(lines[1], "1,2")

    def test_markdown_headings(self) -> None:
        out = render({"role": "expert", "tags": ["a", "b"]}, "markdown")
        self.assertIn("## Role", out)
        self.assertIn("- a", out)

    def test_unknown_format_raises(self) -> None:
        with self.assertRaises(ValueError):
            render(SAMPLE, "toml")

    def test_scaffold_fills_placeholders(self) -> None:
        out = get_template("structured_output", role="a tester", task="extract names")
        self.assertIn("a tester", out)
        self.assertIn("extract names", out)

    def test_unknown_scaffold_raises(self) -> None:
        with self.assertRaises(ValueError):
            get_template("nonsense")


if __name__ == "__main__":
    unittest.main()
