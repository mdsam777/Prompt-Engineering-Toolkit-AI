"""Prompt library: load, validate, index and search the prompt collection.

Prompts live on disk as JSON files under ``prompts/data/<category>/*.json`` (one
prompt per file, or an array of prompts per file). This module loads them into
:class:`~promptforge.schema.Prompt` objects, validates them, and exposes a small
search API with keyword ranking plus category/tag/difficulty/model filters.

The default data directory is resolved relative to the repository so the toolkit
works straight from a checkout. It can be overridden with the
``PROMPTFORGE_PROMPTS_DIR`` environment variable or the ``data_dir`` argument,
which is what the tests and the web API use.
"""

from __future__ import annotations

import json
import os
from collections import Counter
from dataclasses import dataclass
from pathlib import Path

from .schema import Difficulty, Prompt

# Repo-root-relative default: <repo>/prompts/data. ``parents[2]`` walks
# library.py -> promptforge -> src -> repo root.
_DEFAULT_DATA_DIR = Path(__file__).resolve().parents[2] / "prompts" / "data"

# Field weights for keyword search ranking. Title matches matter most.
_FIELD_WEIGHTS = {"title": 3.0, "tags": 2.5, "category": 2.0, "description": 1.5, "body": 1.0}


def resolve_data_dir(data_dir: str | os.PathLike[str] | None = None) -> Path:
    """Resolve the prompts data directory.

    Precedence: explicit ``data_dir`` > ``PROMPTFORGE_PROMPTS_DIR`` env var >
    the repo-root default.
    """
    if data_dir is not None:
        return Path(data_dir)
    env = os.environ.get("PROMPTFORGE_PROMPTS_DIR")
    if env:
        return Path(env)
    return _DEFAULT_DATA_DIR


def load_prompts(
    data_dir: str | os.PathLike[str] | None = None,
    *,
    strict: bool = False,
) -> list[Prompt]:
    """Load every prompt JSON file under ``data_dir``.

    Args:
        data_dir: Directory to scan (recursively). Defaults via
            :func:`resolve_data_dir`.
        strict: When ``True``, raise :class:`ValueError` on the first invalid
            prompt. When ``False`` (default), invalid prompts are skipped so a
            single bad file does not break the whole library.

    Returns:
        Prompts sorted by ``id`` for stable, reproducible ordering.

    Raises:
        FileNotFoundError: if ``data_dir`` does not exist.
        ValueError: in ``strict`` mode, on the first validation failure.
    """
    root = resolve_data_dir(data_dir)
    if not root.exists():
        raise FileNotFoundError(f"prompts data directory not found: {root}")

    prompts: list[Prompt] = []
    for path in sorted(root.rglob("*.json")):
        raw = json.loads(path.read_text(encoding="utf-8"))
        records = raw if isinstance(raw, list) else [raw]
        for record in records:
            prompt = Prompt.from_dict(record)
            problems = prompt.validate()
            if problems:
                message = f"{path.name} -> {prompt.id}: {'; '.join(problems)}"
                if strict:
                    raise ValueError(message)
                continue
            prompts.append(prompt)

    prompts.sort(key=lambda p: p.id)
    return prompts


@dataclass(slots=True)
class SearchHit:
    """A single search result: the prompt plus its relevance score."""

    prompt: Prompt
    score: float


class PromptLibrary:
    """In-memory, searchable view over the prompt collection."""

    def __init__(self, prompts: list[Prompt]):
        self._prompts = list(prompts)
        self._by_id = {p.id: p for p in self._prompts}

    # -- constructors -----------------------------------------------------
    @classmethod
    def load(
        cls,
        data_dir: str | os.PathLike[str] | None = None,
        *,
        strict: bool = False,
    ) -> "PromptLibrary":
        """Load the library from disk (see :func:`load_prompts`)."""
        return cls(load_prompts(data_dir, strict=strict))

    # -- basic access -----------------------------------------------------
    def __len__(self) -> int:
        return len(self._prompts)

    @property
    def prompts(self) -> list[Prompt]:
        """All prompts (a copy, so callers can't mutate internal state)."""
        return list(self._prompts)

    def get(self, prompt_id: str) -> Prompt | None:
        """Return the prompt with ``prompt_id`` or ``None`` if absent."""
        return self._by_id.get(prompt_id)

    def categories(self) -> dict[str, int]:
        """Return ``{category: count}`` sorted by descending count."""
        counter = Counter(p.category for p in self._prompts)
        return dict(counter.most_common())

    def tags(self) -> dict[str, int]:
        """Return ``{tag: count}`` across the whole library."""
        counter: Counter[str] = Counter()
        for prompt in self._prompts:
            counter.update(prompt.tags)
        return dict(counter.most_common())

    # -- search -----------------------------------------------------------
    def search(
        self,
        query: str = "",
        *,
        category: str | None = None,
        tags: list[str] | None = None,
        difficulty: Difficulty | str | None = None,
        model: str | None = None,
        limit: int | None = None,
    ) -> list[SearchHit]:
        """Keyword-search the library with optional filters.

        Filtering is applied first (category, tags, difficulty, model), then the
        remaining prompts are ranked by weighted keyword overlap with ``query``.
        An empty ``query`` returns all filtered prompts ranked alphabetically by
        title, which makes this method double as a "browse" endpoint.

        Args:
            query: Space-separated search terms (case-insensitive).
            category: Restrict to a single category slug.
            tags: Require all of these tags to be present.
            difficulty: Restrict to a difficulty level.
            model: Restrict to prompts supporting this model id (or ``"all"``).
            limit: Maximum number of hits to return.

        Returns:
            Ranked :class:`SearchHit` list (highest score first).
        """
        wanted_difficulty = (
            Difficulty.coerce(difficulty) if difficulty is not None else None
        )
        wanted_tags = {t.lower() for t in (tags or [])}
        terms = [t for t in query.lower().split() if t]

        hits: list[SearchHit] = []
        for prompt in self._prompts:
            if category and prompt.category != category:
                continue
            if wanted_difficulty and prompt.difficulty != wanted_difficulty:
                continue
            if wanted_tags and not wanted_tags.issubset(
                {t.lower() for t in prompt.tags}
            ):
                continue
            if model and not self._supports_model(prompt, model):
                continue

            score = self._relevance(prompt, terms) if terms else 0.0
            if terms and score <= 0:
                continue  # query supplied but nothing matched
            hits.append(SearchHit(prompt=prompt, score=round(score, 3)))

        if terms:
            hits.sort(key=lambda h: (-h.score, h.prompt.title.lower()))
        else:
            hits.sort(key=lambda h: h.prompt.title.lower())

        return hits[:limit] if limit else hits

    # -- internals --------------------------------------------------------
    @staticmethod
    def _supports_model(prompt: Prompt, model: str) -> bool:
        supported = {m.lower() for m in prompt.supported_models}
        return "all" in supported or model.lower() in supported

    @staticmethod
    def _relevance(prompt: Prompt, terms: list[str]) -> float:
        """Weighted keyword-overlap score for ``prompt`` against ``terms``."""
        haystacks = {
            "title": prompt.title.lower(),
            "description": prompt.description.lower(),
            "category": prompt.category.lower(),
            "tags": " ".join(prompt.tags).lower(),
            "body": prompt.body.lower(),
        }
        score = 0.0
        for term in terms:
            for field_name, weight in _FIELD_WEIGHTS.items():
                if term in haystacks[field_name]:
                    score += weight
        return score
