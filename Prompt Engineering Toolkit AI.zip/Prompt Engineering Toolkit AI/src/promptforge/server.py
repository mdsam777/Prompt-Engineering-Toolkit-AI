"""A tiny, dependency-free web server for the Prompt Engineering Toolkit chat app.

Run it and a browser tab opens with a ChatGPT-style interface where you describe
what you need and the local PromptForge engine crafts an optimised prompt.

* Built entirely on :mod:`http.server` from the standard library — no Flask, no
  FastAPI, no pip install required to *run* the app.
* Binds to ``127.0.0.1`` only, so the app is private to your machine.
* Serves the single-page UI from ``web/index.html`` and answers chat turns at
  ``POST /api/chat`` using :func:`promptforge.assistant.respond`.

Launch it any of these ways::

    promptforge serve                 # via the installed CLI
    python -m promptforge.server      # as a module
    python start.py                   # the clickable launcher (repo root)
"""

from __future__ import annotations

import argparse
import json
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from . import __version__
from .assistant import respond

# The UI lives next to this file so it ships with the package.
_WEB_DIR = Path(__file__).resolve().parent / "web"
_INDEX = _WEB_DIR / "index.html"

# Cap request bodies so a malformed/huge POST can't exhaust memory.
_MAX_BODY_BYTES = 256 * 1024


class _Handler(BaseHTTPRequestHandler):
    """Routes: ``GET /`` (UI), ``GET /health``, ``POST /api/chat``."""

    server_version = f"PromptForge/{__version__}"

    # Quieter logging: one tidy line per request instead of the noisy default.
    def log_message(self, fmt: str, *args) -> None:  # noqa: A002 - stdlib signature
        print(f"  [server] {self.address_string()} {fmt % args}")

    # -- helpers ----------------------------------------------------------
    def _send(self, status: int, body: bytes, content_type: str) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        # Local-only app; prevent caching so edits to the UI show immediately.
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _send_json(self, status: int, payload: dict) -> None:
        self._send(status, json.dumps(payload).encode("utf-8"), "application/json; charset=utf-8")

    # -- routes -----------------------------------------------------------
    def do_GET(self) -> None:  # noqa: N802 - stdlib naming
        if self.path in ("/", "/index.html"):
            if not _INDEX.exists():
                self._send(500, b"UI file missing", "text/plain; charset=utf-8")
                return
            self._send(200, _INDEX.read_bytes(), "text/html; charset=utf-8")
        elif self.path == "/health":
            self._send_json(200, {"status": "ok", "version": __version__})
        else:
            self._send_json(404, {"error": "not found"})

    def do_POST(self) -> None:  # noqa: N802 - stdlib naming
        if self.path != "/api/chat":
            self._send_json(404, {"error": "not found"})
            return
        try:
            length = int(self.headers.get("Content-Length", 0))
            if length > _MAX_BODY_BYTES:
                self._send_json(413, {"error": "request too large"})
                return
            raw = self.rfile.read(length) if length else b"{}"
            data = json.loads(raw or b"{}")
            message = str(data.get("message", ""))
            history = data.get("history") or []
            if not isinstance(history, list):
                history = []
            reply = respond(message, history)
            self._send_json(200, reply.to_dict())
        except json.JSONDecodeError:
            self._send_json(400, {"error": "invalid JSON"})
        except Exception as exc:  # last-resort guard so the UI always gets a reply
            self._send_json(
                200,
                {"text": f"⚠️ Internal error: {exc}", "suggestions": [], "kind": "error"},
            )


def _find_free_port(host: str, preferred: int, attempts: int = 25) -> int:
    """Return ``preferred`` if free, otherwise the next available port."""
    import socket

    for offset in range(attempts):
        port = preferred + offset
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                sock.bind((host, port))
                return port
            except OSError:
                continue
    raise OSError(f"no free port found near {preferred}")


def serve(
    host: str = "127.0.0.1",
    port: int = 8765,
    *,
    open_browser: bool = True,
) -> None:
    """Start the chat server and (optionally) open the browser.

    Blocks until interrupted with Ctrl+C. Chooses the next free port if the
    preferred one is busy, so double-clicking the launcher twice won't crash.
    """
    port = _find_free_port(host, port)
    httpd = ThreadingHTTPServer((host, port), _Handler)
    url = f"http://{host}:{port}"

    banner = (
        "\n  ┌──────────────────────────────────────────────┐\n"
        "  │   🔥  Prompt Engineering Toolkit is running     │\n"
        "  └──────────────────────────────────────────────┘\n"
        f"\n  Open in your browser:  {url}\n"
        "  Press Ctrl+C in this window to stop.\n"
    )
    print(banner)

    if open_browser:
        # Open after a short delay so the server is ready to answer the first GET.
        threading.Timer(0.7, lambda: webbrowser.open(url)).start()

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n  Shutting down. Goodbye! 👋")
    finally:
        httpd.server_close()


def main(argv: list[str] | None = None) -> int:
    """CLI entry point for ``python -m promptforge.server``."""
    parser = argparse.ArgumentParser(description="Run the Prompt Engineering Toolkit chat app.")
    parser.add_argument("--host", default="127.0.0.1", help="Bind address (default: 127.0.0.1).")
    parser.add_argument("--port", type=int, default=8765, help="Preferred port (default: 8765).")
    parser.add_argument("--no-browser", action="store_true", help="Don't auto-open the browser.")
    args = parser.parse_args(argv)
    serve(args.host, args.port, open_browser=not args.no_browser)
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
