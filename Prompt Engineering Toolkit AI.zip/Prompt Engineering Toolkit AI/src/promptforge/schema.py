"""Prompt data model and schema.

This module defines the canonical, provider-agnostic representation of a
prompt inside PromptForge. Every prompt in the library — and every prompt
produced by the generator — can be expressed as a :class:`Prompt`.

The schema intentionally mirrors the public JSON schema shipped in
``prompts/schema/prompt.schema.json`` so that library data on disk and the
in-memory objects stay in lockstep. See :func:`Prompt.from_dict` and
:func:`Prompt.to_dict` for the (de)serialisation contract.

Design goals
------------
* **Zero third-party dependencies** — only the Python standard library is used
  so the core engine runs anywhere Python 3.10+ is available.
* **Strict but friendly validation** — :func:`Prompt.validate` returns a list of
  human-readable problems instead of raising, so callers (CLI, CI, web API) can
  decide how to surface them.
* **Stable identifiers** — every prompt carries a slug-style ``id`` that is used
  for cross-referencing via ``related_prompts``.
"""

from __future__ import annotations

import re
from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any

# Semantic version pattern (e.g. "1.0.0"). Library prompts are versioned so the
# version-control feature can diff and roll back individual entries.
_SEMVER_RE = re.compile(r"^\d+\.\d+\.\d+$")

# A slug id: lowercase letters, digits and hyphens. Keeps URLs and file names
# clean and predictable across every operating system.
_SLUG_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")


class Difficulty(str, Enum):
    """How much prompt-engineering experience a prompt assumes.

    Subclassing ``str`` means a :class:`Difficulty` serialises directly to its
    string value in JSON without custom encoders.
    """

    BEGINNER = "beginner"
    INTERMEDIATE = "intermediate"
    ADVANCED = "advanced"
    EXPERT = "expert"

    @classmethod
    def coerce(cls, value: "Difficulty | str") -> "Difficulty":
        """Return a :class:`Difficulty` from either an enum member or a string.

        Raises:
            ValueError: if ``value`` is not a recognised difficulty.
        """
        if isinstance(value, Difficulty):
            return value
        try:
            return cls(str(value).strip().lower())
        except ValueError as exc:  # pragma: no cover - exercised via validate()
            valid = ", ".join(d.value for d in cls)
            raise ValueError(
                f"unknown difficulty {value!r}; expected one of: {valid}"
            ) from exc


@dataclass(slots=True)
class Prompt:
    """A single, fully-documented prompt.

    The required fields map one-to-one onto the documentation contract every
    library prompt must satisfy: Title, Description, Difficulty, Expected
    Output, Supported AI Models, Example, Best Practices, Common Mistakes,
    Version, Tags and Related Prompts.

    Attributes:
        id: Stable slug identifier, unique across the library.
        title: Human-readable name.
        description: One or two sentences explaining what the prompt does.
        category: Top-level category slug (e.g. ``"programming"``).
        difficulty: Assumed experience level.
        body: The actual prompt text. May contain ``{placeholders}`` that the
            user fills in.
        expected_output: A description of what a good model response looks like.
        supported_models: Model/provider ids this prompt is tuned for. Use
            ``"all"`` for provider-agnostic prompts.
        example: A concrete, filled-in usage example.
        best_practices: Tips that make the prompt perform well.
        common_mistakes: Pitfalls to avoid.
        version: Semantic version string for this prompt entry.
        tags: Free-form search keywords.
        related_prompts: ``id`` values of complementary prompts.
        language: ISO-639-1 language code of ``body`` (default ``"en"``).
        author: Attribution for the contributor.
        source: Optional URL or citation backing the prompt.
    """

    id: str
    title: str
    description: str
    category: str
    difficulty: Difficulty
    body: str
    expected_output: str
    supported_models: list[str]
    example: str
    best_practices: list[str]
    common_mistakes: list[str]
    version: str
    tags: list[str]
    related_prompts: list[str] = field(default_factory=list)
    language: str = "en"
    author: str = "PromptForge Community"
    source: str | None = None

    # -- (de)serialisation ------------------------------------------------
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Prompt":
        """Build a :class:`Prompt` from a plain ``dict`` (e.g. parsed JSON).

        Unknown keys are ignored so the on-disk format can grow new optional
        fields without breaking older readers.
        """
        return cls(
            id=str(data["id"]),
            title=str(data["title"]),
            description=str(data["description"]),
            category=str(data["category"]),
            difficulty=Difficulty.coerce(data["difficulty"]),
            body=str(data["body"]),
            expected_output=str(data["expected_output"]),
            supported_models=list(data.get("supported_models", [])),
            example=str(data["example"]),
            best_practices=list(data.get("best_practices", [])),
            common_mistakes=list(data.get("common_mistakes", [])),
            version=str(data["version"]),
            tags=list(data.get("tags", [])),
            related_prompts=list(data.get("related_prompts", [])),
            language=str(data.get("language", "en")),
            author=str(data.get("author", "PromptForge Community")),
            source=data.get("source"),
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialise to a JSON-ready ``dict`` with the enum rendered as a string."""
        data = asdict(self)
        data["difficulty"] = self.difficulty.value
        if self.source is None:
            data.pop("source")
        return data

    # -- validation -------------------------------------------------------
    def validate(self) -> list[str]:
        """Return a list of human-readable validation problems.

        An empty list means the prompt is valid. This never raises so it can be
        used to accumulate every problem in a batch (e.g. CI over the library).
        """
        problems: list[str] = []

        if not _SLUG_RE.match(self.id):
            problems.append(
                f"id {self.id!r} must be a lowercase hyphenated slug"
            )
        for name in ("title", "description", "body", "expected_output", "example"):
            if not str(getattr(self, name)).strip():
                problems.append(f"{name} must not be empty")
        if not _SEMVER_RE.match(self.version):
            problems.append(
                f"version {self.version!r} must be semantic (e.g. '1.0.0')"
            )
        if not self.supported_models:
            problems.append("supported_models must list at least one model")
        if not self.tags:
            problems.append("tags must contain at least one keyword")
        if len(self.description) > 280:
            problems.append("description should be <= 280 characters")

        return problems

    @property
    def is_valid(self) -> bool:
        """``True`` when :meth:`validate` finds no problems."""
        return not self.validate()
