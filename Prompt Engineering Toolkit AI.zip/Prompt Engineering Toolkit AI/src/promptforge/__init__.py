"""PromptForge — the open-source Prompt Engineering Toolkit (core engine).

This package is the provider-agnostic heart of PromptForge. Everything here is
pure Python with **no third-party dependencies**, fully deterministic and unit
tested, so it can be embedded in a CLI, a FastAPI backend, CI pipelines, or any
other host.

Quick start
-----------
>>> import promptforge as pf
>>> result = pf.score_prompt("write code")
>>> result.overall < 60
True
>>> opt = pf.optimize("write code")
>>> opt.after.overall >= opt.before.overall
True

Public surface
--------------
* :func:`score_prompt` — 10-dimension, 0-100 prompt scoring.
* :func:`optimize` — rewrite a prompt into a structured, higher-scoring form.
* :func:`generate` / :class:`GeneratorSpec` — build a prompt from a spec.
* :class:`PromptLibrary` — load and search the prompt collection.
* :func:`render` / :func:`get_template` — multi-format templates.
* :data:`REGISTRY`, :func:`compare`, :func:`get_model` — model metadata.
"""

from __future__ import annotations

from .analysis import (
    OptimizedPrompt,
    ScoreResult,
    TextStats,
    analyze_text,
    estimate_tokens,
    optimize,
    score_prompt,
)
from .generator import GeneratedPrompt, GeneratorSpec, generate
from .library import PromptLibrary, SearchHit, load_prompts
from .models import REGISTRY, ModelInfo, compare, get_model, list_models
from .schema import Difficulty, Prompt
from .templates import get_template, render

__version__ = "0.1.0"

__all__ = [
    "__version__",
    # analysis
    "score_prompt",
    "ScoreResult",
    "optimize",
    "OptimizedPrompt",
    "analyze_text",
    "estimate_tokens",
    "TextStats",
    # generator
    "generate",
    "GeneratorSpec",
    "GeneratedPrompt",
    # library
    "PromptLibrary",
    "SearchHit",
    "load_prompts",
    # models
    "REGISTRY",
    "ModelInfo",
    "compare",
    "get_model",
    "list_models",
    # schema
    "Prompt",
    "Difficulty",
    # templates
    "render",
    "get_template",
]
