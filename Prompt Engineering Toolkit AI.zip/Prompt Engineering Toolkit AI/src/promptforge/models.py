"""Registry of supported AI models and a comparison helper.

PromptForge is provider-agnostic. This module records *indicative* metadata for
the major model families so the toolkit can:

* tag prompts with the models they target,
* power the "AI Model Comparison" feature,
* estimate token cost in the testing/playground features.

.. important::
   The numbers below (context windows, prices, capability ratings) are
   **indicative defaults**, not a live price feed. Providers change pricing and
   limits frequently. Always verify against the official provider docs before
   relying on them for billing. Every field can be overridden by the caller, and
   :data:`REGISTRY_AS_OF` records when these defaults were last reviewed.

Capability ratings (``coding``, ``reasoning``, ``creativity``, ``speed``) are an
editorial 1-5 scale meant for *relative* comparison only, not benchmark scores.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable

#: Month these indicative defaults were last reviewed. Surfaced in the CLI and
#: docs so consumers know how stale the figures may be.
REGISTRY_AS_OF = "2026-01"

#: Capability dimensions used by the comparison feature.
CAPABILITY_DIMS = ("coding", "reasoning", "creativity", "speed")


@dataclass(slots=True, frozen=True)
class ModelInfo:
    """Indicative specification for a single model.

    Attributes:
        id: Stable identifier used throughout the toolkit (e.g. ``"gpt"``).
        name: Human-readable display name.
        provider: Organisation that ships the model.
        family: Short family/brand label.
        context_window: Approx. max input tokens.
        max_output_tokens: Approx. max tokens the model will generate.
        input_cost_per_mtok: Indicative USD price per 1M input tokens.
        output_cost_per_mtok: Indicative USD price per 1M output tokens.
        supports_tools: Whether tool/function calling is supported.
        supports_vision: Whether image input is supported.
        supports_json_mode: Whether a strict JSON output mode exists.
        coding/reasoning/creativity/speed: Editorial 1-5 capability ratings.
        notes: Free-form caveats.
    """

    id: str
    name: str
    provider: str
    family: str
    context_window: int
    max_output_tokens: int
    input_cost_per_mtok: float
    output_cost_per_mtok: float
    supports_tools: bool = True
    supports_vision: bool = False
    supports_json_mode: bool = True
    coding: int = 3
    reasoning: int = 3
    creativity: int = 3
    speed: int = 3
    notes: str = ""

    def estimate_cost(self, input_tokens: int, output_tokens: int) -> float:
        """Estimate request cost in USD for a given token split.

        Args:
            input_tokens: Number of prompt tokens.
            output_tokens: Number of completion tokens.

        Returns:
            Indicative cost in US dollars (rounded to 6 decimals).
        """
        cost = (
            input_tokens / 1_000_000 * self.input_cost_per_mtok
            + output_tokens / 1_000_000 * self.output_cost_per_mtok
        )
        return round(cost, 6)

    def capabilities(self) -> dict[str, int]:
        """Return the capability ratings as a ``{dimension: score}`` mapping."""
        return {dim: getattr(self, dim) for dim in CAPABILITY_DIMS}


# ---------------------------------------------------------------------------
# The registry. Keyed by stable id. Values are indicative — see module docstring.
# ---------------------------------------------------------------------------
_MODELS: tuple[ModelInfo, ...] = (
    ModelInfo(
        id="gpt",
        name="ChatGPT (GPT family)",
        provider="OpenAI",
        family="GPT",
        context_window=128_000,
        max_output_tokens=16_384,
        input_cost_per_mtok=2.5,
        output_cost_per_mtok=10.0,
        supports_vision=True,
        coding=5,
        reasoning=5,
        creativity=4,
        speed=3,
        notes="Strong general-purpose model with mature tool-calling support.",
    ),
    ModelInfo(
        id="claude",
        name="Claude",
        provider="Anthropic",
        family="Claude",
        context_window=200_000,
        max_output_tokens=64_000,
        input_cost_per_mtok=3.0,
        output_cost_per_mtok=15.0,
        supports_vision=True,
        coding=5,
        reasoning=5,
        creativity=5,
        speed=3,
        notes="Large context window; excels at long-form reasoning and writing.",
    ),
    ModelInfo(
        id="gemini",
        name="Gemini",
        provider="Google",
        family="Gemini",
        context_window=1_000_000,
        max_output_tokens=8_192,
        input_cost_per_mtok=1.25,
        output_cost_per_mtok=5.0,
        supports_vision=True,
        coding=4,
        reasoning=4,
        creativity=4,
        speed=4,
        notes="Very large context window and strong multimodal support.",
    ),
    ModelInfo(
        id="grok",
        name="Grok",
        provider="xAI",
        family="Grok",
        context_window=131_072,
        max_output_tokens=16_384,
        input_cost_per_mtok=2.0,
        output_cost_per_mtok=10.0,
        supports_vision=True,
        coding=4,
        reasoning=4,
        creativity=4,
        speed=4,
        notes="Real-time leaning model with web/X awareness in hosted products.",
    ),
    ModelInfo(
        id="deepseek",
        name="DeepSeek",
        provider="DeepSeek",
        family="DeepSeek",
        context_window=128_000,
        max_output_tokens=8_192,
        input_cost_per_mtok=0.27,
        output_cost_per_mtok=1.10,
        supports_vision=False,
        coding=5,
        reasoning=5,
        creativity=3,
        speed=3,
        notes="Cost-efficient with strong coding and reasoning performance.",
    ),
    ModelInfo(
        id="llama",
        name="Llama",
        provider="Meta",
        family="Llama",
        context_window=128_000,
        max_output_tokens=8_192,
        input_cost_per_mtok=0.20,
        output_cost_per_mtok=0.60,
        supports_vision=True,
        coding=4,
        reasoning=4,
        creativity=3,
        speed=4,
        notes="Open-weight; self-hostable, pricing depends on the host.",
    ),
    ModelInfo(
        id="mistral",
        name="Mistral",
        provider="Mistral AI",
        family="Mistral",
        context_window=128_000,
        max_output_tokens=8_192,
        input_cost_per_mtok=0.40,
        output_cost_per_mtok=2.0,
        supports_vision=False,
        coding=4,
        reasoning=4,
        creativity=4,
        speed=5,
        notes="Open-weight options available; fast and efficient.",
    ),
    ModelInfo(
        id="qwen",
        name="Qwen",
        provider="Alibaba",
        family="Qwen",
        context_window=131_072,
        max_output_tokens=8_192,
        input_cost_per_mtok=0.30,
        output_cost_per_mtok=1.20,
        supports_vision=True,
        coding=5,
        reasoning=4,
        creativity=3,
        speed=4,
        notes="Open-weight family with strong multilingual and coding skills.",
    ),
    ModelInfo(
        id="perplexity",
        name="Perplexity",
        provider="Perplexity",
        family="Sonar",
        context_window=127_072,
        max_output_tokens=8_192,
        input_cost_per_mtok=1.0,
        output_cost_per_mtok=1.0,
        supports_tools=False,
        supports_vision=False,
        coding=3,
        reasoning=4,
        creativity=3,
        speed=4,
        notes="Answer engine with built-in web search and citations.",
    ),
)

#: Public, read-only registry keyed by model id.
REGISTRY: dict[str, ModelInfo] = {m.id: m for m in _MODELS}

#: Reserved id meaning "any/all supported models".
ANY_MODEL = "all"


def list_models() -> list[ModelInfo]:
    """Return all registered models, ordered by id."""
    return [REGISTRY[k] for k in sorted(REGISTRY)]


def get_model(model_id: str) -> ModelInfo:
    """Look up a model by id (case-insensitive).

    Raises:
        KeyError: if the id is unknown.
    """
    key = model_id.strip().lower()
    if key not in REGISTRY:
        valid = ", ".join(sorted(REGISTRY))
        raise KeyError(f"unknown model {model_id!r}; known ids: {valid}")
    return REGISTRY[key]


def is_known_model(model_id: str) -> bool:
    """Return ``True`` if ``model_id`` is registered or the wildcard ``all``."""
    key = model_id.strip().lower()
    return key == ANY_MODEL or key in REGISTRY


def compare(
    model_ids: Iterable[str],
    dimensions: Iterable[str] = CAPABILITY_DIMS,
) -> dict[str, dict[str, object]]:
    """Build a comparison table for the given models.

    Args:
        model_ids: Ids of the models to compare.
        dimensions: Capability dimensions to include.

    Returns:
        A mapping ``{model_id: {dimension: value, ...}}`` that also includes the
        context window, max output and indicative prices for each model.

    Raises:
        KeyError: if any model id is unknown.
    """
    dims = tuple(dimensions)
    table: dict[str, dict[str, object]] = {}
    for mid in model_ids:
        model = get_model(mid)
        row: dict[str, object] = {dim: getattr(model, dim) for dim in dims}
        row["context_window"] = model.context_window
        row["max_output_tokens"] = model.max_output_tokens
        row["input_cost_per_mtok"] = model.input_cost_per_mtok
        row["output_cost_per_mtok"] = model.output_cost_per_mtok
        table[model.id] = row
    return table
