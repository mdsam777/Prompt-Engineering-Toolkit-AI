"""Data-integrity tests for the shipped prompt library.

These run in CI so a malformed contributed prompt fails the build before merge.
"""

from __future__ import annotations

import unittest

from promptforge.library import load_prompts


class PromptDataTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        # strict=True surfaces any schema violation as an exception.
        cls.prompts = load_prompts(strict=True)

    def test_prompts_exist(self) -> None:
        self.assertGreater(len(self.prompts), 0)

    def test_all_prompts_validate(self) -> None:
        for prompt in self.prompts:
            self.assertEqual(prompt.validate(), [], f"{prompt.id} failed validation")

    def test_ids_are_unique(self) -> None:
        ids = [p.id for p in self.prompts]
        self.assertEqual(len(ids), len(set(ids)), "duplicate prompt ids found")

    def test_related_prompts_reference_existing_ids(self) -> None:
        known = {p.id for p in self.prompts}
        for prompt in self.prompts:
            for ref in prompt.related_prompts:
                self.assertIn(
                    ref, known,
                    f"{prompt.id} references unknown related prompt {ref!r}",
                )

    def test_category_matches_directory_slug(self) -> None:
        # Every prompt's category should be a non-empty slug.
        for prompt in self.prompts:
            self.assertTrue(prompt.category.strip())


if __name__ == "__main__":
    unittest.main()
