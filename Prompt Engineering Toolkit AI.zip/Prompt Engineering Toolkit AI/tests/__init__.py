"""Test package bootstrap.

Adds the ``src/`` directory to ``sys.path`` so the test suite can ``import
promptforge`` whether it is run via ``python -m unittest`` or ``pytest``, with or
without an editable install. This keeps the tests runnable straight from a clean
checkout on any machine with Python 3.10+.
"""

from __future__ import annotations

import os
import sys

_SRC = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src")
if _SRC not in sys.path:
    sys.path.insert(0, _SRC)
