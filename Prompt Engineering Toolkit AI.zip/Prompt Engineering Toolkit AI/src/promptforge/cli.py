"""Command-line interface for PromptForge.

A single, dependency-free entry point that exposes the core engine from the
terminal::

    promptforge score "write code"
    promptforge optimize "write code" --output-format JSON
    promptforge generate --goal "Explain CTEs" --industry data --length short
    promptforge search sql --category data-analysis
    promptforge models compare gpt claude deepseek
    promptforge template structured_output --task "Extract entities"
    promptforge validate

Every command supports ``--json`` for machine-readable output, so the CLI can be
scripted or wired into CI. The module is intentionally thin: it parses arguments
and delegates to the library, keeping all logic testable in one place.
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Sequence

from . import __version__
from .analysis.optimizer import optimize
from .analysis.scoring import score_prompt
from .generator import GeneratorSpec, generate
from .library import PromptLibrary
from .models import CAPABILITY_DIMS, REGISTRY_AS_OF, compare, get_model, list_models
from .templates import TEMPLATE_NAMES, get_template


def _read_text(value: str | None, file: str | None) -> str:
    """Return prompt text from a positional arg, a ``--file`` path, or stdin."""
    if file:
        with open(file, "r", encoding="utf-8") as handle:
            return handle.read()
    if value:
        return value
    if not sys.stdin.isatty():
        return sys.stdin.read()
    raise SystemExit("error: provide prompt text, --file PATH, or pipe via stdin")


def _print_bar(label: str, score: float, width: int = 24) -> None:
    """Render a labelled 0-100 score as a simple text bar."""
    filled = round(score / 100 * width)
    bar = "#" * filled + "-" * (width - filled)
    print(f"  {label:<20} [{bar}] {score:>5.1f}")


# --- command handlers -----------------------------------------------------
def _cmd_score(args: argparse.Namespace) -> int:
    text = _read_text(args.prompt, args.file)
    result = score_prompt(text)
    if args.json:
        print(json.dumps(result.to_dict(), indent=2))
        return 0
    print(f"\nOverall: {result.overall}/100  (grade {result.grade})\n")
    for name, metric in result.dimensions.items():
        _print_bar(name, metric.score)
    if result.suggestions:
        print("\nTop suggestions:")
        for suggestion in result.suggestions[:5]:
            print(f"  - {suggestion}")
    print()
    return 0


def _cmd_optimize(args: argparse.Namespace) -> int:
    text = _read_text(args.prompt, args.file)
    result = optimize(text, output_format=args.output_format)
    if args.json:
        print(json.dumps(result.to_dict(), indent=2))
        return 0
    before = result.before.overall if result.before else 0.0
    after = result.after.overall if result.after else 0.0
    print(f"\nScore: {before} -> {after}  (delta +{result.delta})\n")
    print("Changes applied:")
    for change in result.changes:
        print(f"  - {change}")
    print("\n--- Improved prompt ---\n")
    print(result.improved)
    print()
    return 0


def _cmd_generate(args: argparse.Namespace) -> int:
    spec = GeneratorSpec(
        goal=args.goal,
        industry=args.industry,
        output_style=args.output_style,
        tone=args.tone,
        model=args.model,
        length=args.length,
        language=args.language,
        audience=args.audience,
    )
    result = generate(spec)
    if args.json:
        print(json.dumps(result.to_dict(), indent=2))
        return 0
    score = result.score.overall if result.score else 0.0
    print(f"\nGenerated prompt (score {score}/100):\n")
    print(result.prompt)
    if result.notes:
        print("\nNotes:")
        for note in result.notes:
            print(f"  - {note}")
    print()
    return 0


def _cmd_search(args: argparse.Namespace) -> int:
    library = PromptLibrary.load(args.data_dir)
    hits = library.search(
        args.query,
        category=args.category,
        tags=args.tag,
        difficulty=args.difficulty,
        model=args.model,
        limit=args.limit,
    )
    if args.json:
        payload = [
            {"id": h.prompt.id, "title": h.prompt.title, "score": h.score,
             "category": h.prompt.category, "difficulty": h.prompt.difficulty.value}
            for h in hits
        ]
        print(json.dumps(payload, indent=2))
        return 0
    if not hits:
        print("No matching prompts.")
        return 0
    print(f"\n{len(hits)} result(s):\n")
    for hit in hits:
        prompt = hit.prompt
        print(f"  [{prompt.category}/{prompt.difficulty.value}] {prompt.title}")
        print(f"      id: {prompt.id}  score: {hit.score}")
        print(f"      {prompt.description}")
    print()
    return 0


def _cmd_models(args: argparse.Namespace) -> int:
    if args.action == "compare":
        if len(args.ids) < 2:
            raise SystemExit("error: 'models compare' needs at least two model ids")
        table = compare(args.ids)
        if args.json:
            print(json.dumps(table, indent=2))
            return 0
        dims = list(CAPABILITY_DIMS) + ["context_window", "input_cost_per_mtok"]
        header = "  metric".ljust(22) + "".join(f"{mid:>14}" for mid in table)
        print(f"\nModel comparison (indicative, as of {REGISTRY_AS_OF}):\n")
        print(header)
        for dim in dims:
            row = f"  {dim:<20}" + "".join(
                f"{str(table[mid][dim]):>14}" for mid in table
            )
            print(row)
        print()
        return 0

    # default: list
    models = list_models()
    if args.json:
        print(json.dumps(
            [{"id": m.id, "name": m.name, "provider": m.provider,
              "context_window": m.context_window} for m in models],
            indent=2,
        ))
        return 0
    print(f"\nSupported models (indicative specs, as of {REGISTRY_AS_OF}):\n")
    for model in models:
        print(f"  {model.id:<12} {model.name:<26} ({model.provider})")
        print(f"      context {model.context_window:,} tok | "
              f"${model.input_cost_per_mtok}/${model.output_cost_per_mtok} per Mtok")
    print()
    return 0


def _cmd_template(args: argparse.Namespace) -> int:
    text = get_template(args.name, role=args.role, task=args.task, model=args.model)
    print(text)
    return 0


def _cmd_serve(args: argparse.Namespace) -> int:
    # Imported lazily so the rest of the CLI has no web dependency at import time.
    from .server import serve

    serve(args.host, args.port, open_browser=not args.no_browser)
    return 0


def _cmd_validate(args: argparse.Namespace) -> int:
    # strict=True raises on the first invalid prompt; we catch and report nicely.
    try:
        library = PromptLibrary.load(args.data_dir, strict=True)
    except ValueError as exc:
        print(f"INVALID: {exc}")
        return 1
    print(f"OK: {len(library)} prompt(s) valid across "
          f"{len(library.categories())} categories.")
    return 0


# --- parser ---------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    """Construct the full argument parser (exposed for tests and docs)."""
    parser = argparse.ArgumentParser(
        prog="promptforge",
        description="PromptForge — the open-source Prompt Engineering Toolkit.",
    )
    parser.add_argument("--version", action="version", version=f"promptforge {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    # score
    p_score = sub.add_parser("score", help="Score a prompt across 10 dimensions.")
    p_score.add_argument("prompt", nargs="?", help="Prompt text.")
    p_score.add_argument("-f", "--file", help="Read the prompt from a file.")
    p_score.add_argument("--json", action="store_true", help="Output JSON.")
    p_score.set_defaults(func=_cmd_score)

    # optimize
    p_opt = sub.add_parser("optimize", help="Rewrite a prompt into a better form.")
    p_opt.add_argument("prompt", nargs="?", help="Prompt text.")
    p_opt.add_argument("-f", "--file", help="Read the prompt from a file.")
    p_opt.add_argument("--output-format", help="Desired response format (e.g. JSON).")
    p_opt.add_argument("--json", action="store_true", help="Output JSON.")
    p_opt.set_defaults(func=_cmd_optimize)

    # generate
    p_gen = sub.add_parser("generate", help="Generate a prompt from a spec.")
    p_gen.add_argument("--goal", required=True, help="What you want to achieve.")
    p_gen.add_argument("--industry", default="general")
    p_gen.add_argument("--output-style", default="Markdown")
    p_gen.add_argument("--tone", default="professional")
    p_gen.add_argument("--model", default="all")
    p_gen.add_argument("--length", default="medium", choices=["short", "medium", "long"])
    p_gen.add_argument("--language", default="English")
    p_gen.add_argument("--audience", default="a general audience")
    p_gen.add_argument("--json", action="store_true", help="Output JSON.")
    p_gen.set_defaults(func=_cmd_generate)

    # search
    p_search = sub.add_parser("search", help="Search the prompt library.")
    p_search.add_argument("query", nargs="?", default="", help="Search terms.")
    p_search.add_argument("--category")
    p_search.add_argument("--tag", action="append", help="Require this tag (repeatable).")
    p_search.add_argument("--difficulty", choices=["beginner", "intermediate", "advanced", "expert"])
    p_search.add_argument("--model", help="Restrict to prompts supporting this model id.")
    p_search.add_argument("--limit", type=int)
    p_search.add_argument("--data-dir", help="Override the prompts data directory.")
    p_search.add_argument("--json", action="store_true", help="Output JSON.")
    p_search.set_defaults(func=_cmd_search)

    # models
    p_models = sub.add_parser("models", help="List or compare supported models.")
    p_models.add_argument("action", nargs="?", default="list", choices=["list", "compare"])
    p_models.add_argument("ids", nargs="*", help="Model ids for 'compare'.")
    p_models.add_argument("--json", action="store_true", help="Output JSON.")
    p_models.set_defaults(func=_cmd_models)

    # template
    p_tpl = sub.add_parser("template", help="Print an advanced prompt scaffold.")
    p_tpl.add_argument("name", choices=list(TEMPLATE_NAMES))
    p_tpl.add_argument("--role", default="an expert assistant")
    p_tpl.add_argument("--task", default="<describe the task>")
    p_tpl.add_argument("--model", default="gpt")
    p_tpl.set_defaults(func=_cmd_template)

    # validate
    p_val = sub.add_parser("validate", help="Validate the prompt library against the schema.")
    p_val.add_argument("--data-dir", help="Override the prompts data directory.")
    p_val.set_defaults(func=_cmd_validate)

    # serve (the chat web app)
    p_serve = sub.add_parser("serve", help="Launch the local chat web app in your browser.")
    p_serve.add_argument("--host", default="127.0.0.1", help="Bind address.")
    p_serve.add_argument("--port", type=int, default=8765, help="Preferred port.")
    p_serve.add_argument("--no-browser", action="store_true", help="Don't auto-open the browser.")
    p_serve.set_defaults(func=_cmd_serve)

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """CLI entry point. Returns a process exit code.

    Args:
        argv: Argument list (defaults to ``sys.argv[1:]``).
    """
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
