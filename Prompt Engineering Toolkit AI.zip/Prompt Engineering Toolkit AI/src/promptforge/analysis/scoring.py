"""The Prompt Scoring Engine.

Combines the per-dimension :mod:`metrics` into a single, weighted 0-100 score
with a letter grade, a full breakdown, and a de-duplicated list of improvement
suggestions. The result is a plain dataclass that serialises cleanly to JSON for
the CLI, the web API and the testing/version-control features.

Weights are deliberately explicit and documented so the scoring is transparent
and tunable. They sum to 1.0; :func:`score_prompt` asserts this on import-time
data to prevent silent drift.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .metrics import ANALYZERS, MetricResult
from .text_stats import TextStats, analyze_text

#: Relative importance of each dimension in the overall score. Tuned so that
#: clarity, specificity and reliability — the factors that most affect real
#: output quality — dominate, while still rewarding good structure and safety.
WEIGHTS: dict[str, float] = {
    "clarity": 0.16,
    "specificity": 0.16,
    "reliability": 0.12,
    "context": 0.11,
    "formatting": 0.10,
    "output_consistency": 0.09,
    "reasoning": 0.08,
    "chain_of_thought": 0.06,
    "token_efficiency": 0.06,
    "safety": 0.06,
}


def _grade(score: float) -> str:
    """Map a 0-100 score to a letter grade for at-a-glance feedback."""
    if score >= 90:
        return "A"
    if score >= 80:
        return "B"
    if score >= 70:
        return "C"
    if score >= 60:
        return "D"
    return "F"


@dataclass(slots=True)
class ScoreResult:
    """Full output of the scoring engine.

    Attributes:
        overall: Weighted 0-100 score.
        grade: Letter grade derived from ``overall``.
        dimensions: Per-dimension :class:`MetricResult` objects.
        suggestions: De-duplicated, prioritised improvement suggestions.
        stats: The underlying text statistics (handy for UIs and debugging).
    """

    overall: float
    grade: str
    dimensions: dict[str, MetricResult]
    suggestions: list[str] = field(default_factory=list)
    stats: TextStats | None = None

    def to_dict(self) -> dict[str, object]:
        """Serialise to a JSON-ready ``dict``."""
        return {
            "overall": self.overall,
            "grade": self.grade,
            "dimensions": {
                name: {
                    "score": m.score,
                    "findings": m.findings,
                    "suggestions": m.suggestions,
                }
                for name, m in self.dimensions.items()
            },
            "suggestions": self.suggestions,
            "estimated_tokens": self.stats.estimated_tokens if self.stats else None,
        }


def score_prompt(prompt: str) -> ScoreResult:
    """Score ``prompt`` across every dimension and return a :class:`ScoreResult`.

    The function is pure and deterministic: the same prompt always produces the
    same score, which is what makes it safe to use in CI quality gates.

    Args:
        prompt: The raw prompt text to evaluate.

    Returns:
        A populated :class:`ScoreResult`.
    """
    # Weights must stay normalised; a drifting table would silently skew scores.
    assert abs(sum(WEIGHTS.values()) - 1.0) < 1e-9, "WEIGHTS must sum to 1.0"

    stats = analyze_text(prompt)
    dimensions: dict[str, MetricResult] = {}
    overall = 0.0

    for analyzer in ANALYZERS:
        result = analyzer(stats)
        dimensions[result.name] = result
        overall += result.score * WEIGHTS[result.name]

    # Surface the suggestions from the weakest dimensions first so users fix the
    # highest-impact problems before cosmetic ones.
    ranked = sorted(dimensions.values(), key=lambda m: m.score)
    seen: set[str] = set()
    suggestions: list[str] = []
    for metric in ranked:
        for suggestion in metric.suggestions:
            if suggestion not in seen:
                seen.add(suggestion)
                suggestions.append(suggestion)

    return ScoreResult(
        overall=round(overall, 1),
        grade=_grade(overall),
        dimensions=dimensions,
        suggestions=suggestions,
        stats=stats,
    )
