"""Prompt template rendering and reusable scaffolds.

Two responsibilities:

1. **Format renderers** — turn a structured prompt (a plain ``dict``) into any of
   the supported serialisation formats: JSON, Markdown, YAML, XML and CSV. The
   YAML and XML emitters are tiny, dependency-free implementations that cover the
   shapes PromptForge produces (scalars, lists and nested dicts).

2. **Ready-made scaffolds** — battle-tested template skeletons for common
   advanced patterns: strict structured output, tool calling, function calling
   and raw API request bodies. Fetch them with :func:`get_template`.

Keeping this in one module means the playground/export features have a single,
well-tested place to convert prompts between formats.
"""

from __future__ import annotations

import csv
import io
import json
from typing import Any
from xml.sax.saxutils import escape as _xml_escape

#: Serialisation formats understood by :func:`render`.
RENDER_FORMATS = ("json", "markdown", "yaml", "xml", "csv")

#: Named advanced scaffolds available via :func:`get_template`.
TEMPLATE_NAMES = (
    "structured_output",
    "tool_calling",
    "function_calling",
    "api_prompt",
)


# --- YAML -----------------------------------------------------------------
def _yaml_scalar(value: Any) -> str:
    """Render a scalar as YAML, quoting only when necessary."""
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    text = str(value)
    # Multi-line strings use a literal block scalar to stay readable.
    if "\n" in text:
        indented = "\n".join("  " + line for line in text.splitlines())
        return "|\n" + indented
    # Quote when the value could be misread as YAML syntax.
    if text == "" or text[0] in "!&*?{}[],#|>@`\"'%" or ": " in text or text.strip() != text:
        return json.dumps(text)  # JSON strings are valid YAML and handle escaping
    return text


def to_yaml(obj: Any, indent: int = 0) -> str:
    """Serialise ``obj`` (dicts/lists/scalars) to a YAML string."""
    pad = "  " * indent
    if isinstance(obj, dict):
        if not obj:
            return f"{pad}{{}}"
        lines: list[str] = []
        for key, value in obj.items():
            if isinstance(value, (dict, list)) and value:
                lines.append(f"{pad}{key}:")
                lines.append(to_yaml(value, indent + 1))
            else:
                lines.append(f"{pad}{key}: {_yaml_scalar(value)}")
        return "\n".join(lines)
    if isinstance(obj, list):
        if not obj:
            return f"{pad}[]"
        lines = []
        for item in obj:
            if isinstance(item, (dict, list)) and item:
                rendered = to_yaml(item, indent + 1).lstrip()
                lines.append(f"{pad}- {rendered}")
            else:
                lines.append(f"{pad}- {_yaml_scalar(item)}")
        return "\n".join(lines)
    return f"{pad}{_yaml_scalar(obj)}"


# --- XML ------------------------------------------------------------------
def to_xml(obj: Any, root: str = "prompt", indent: int = 0) -> str:
    """Serialise ``obj`` to indented XML under a ``root`` element."""
    pad = "  " * indent

    def render_value(tag: str, value: Any, depth: int) -> str:
        inner_pad = "  " * depth
        safe_tag = _safe_tag(tag)
        if isinstance(value, dict):
            children = "\n".join(
                render_value(k, v, depth + 1) for k, v in value.items()
            )
            return f"{inner_pad}<{safe_tag}>\n{children}\n{inner_pad}</{safe_tag}>"
        if isinstance(value, list):
            children = "\n".join(
                render_value("item", v, depth + 1) for v in value
            )
            return f"{inner_pad}<{safe_tag}>\n{children}\n{inner_pad}</{safe_tag}>"
        return f"{inner_pad}<{safe_tag}>{_xml_escape(str(value))}</{safe_tag}>"

    body = (
        "\n".join(render_value(k, v, indent + 1) for k, v in obj.items())
        if isinstance(obj, dict)
        else render_value("item", obj, indent + 1)
    )
    return f"{pad}<{root}>\n{body}\n{pad}</{root}>"


def _safe_tag(tag: str) -> str:
    """Coerce an arbitrary key into a valid XML element name."""
    cleaned = "".join(ch if (ch.isalnum() or ch in "-_") else "_" for ch in str(tag))
    if not cleaned or not (cleaned[0].isalpha() or cleaned[0] == "_"):
        cleaned = "_" + cleaned
    return cleaned


# --- CSV ------------------------------------------------------------------
def to_csv(obj: Any) -> str:
    """Serialise ``obj`` to CSV.

    A list of flat dicts becomes a table; a single dict becomes a two-column
    ``key,value`` sheet. Nested values are JSON-encoded so nothing is lost.
    """
    buffer = io.StringIO()
    if isinstance(obj, list) and obj and isinstance(obj[0], dict):
        fieldnames: list[str] = []
        for row in obj:
            for key in row:
                if key not in fieldnames:
                    fieldnames.append(key)
        writer = csv.DictWriter(buffer, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        for row in obj:
            writer.writerow({k: _csv_cell(row.get(k, "")) for k in fieldnames})
    elif isinstance(obj, dict):
        writer = csv.writer(buffer, lineterminator="\n")
        writer.writerow(["key", "value"])
        for key, value in obj.items():
            writer.writerow([key, _csv_cell(value)])
    else:
        writer = csv.writer(buffer, lineterminator="\n")
        writer.writerow(["value"])
        writer.writerow([_csv_cell(obj)])
    return buffer.getvalue().rstrip("\n")


def _csv_cell(value: Any) -> str:
    """Flatten a cell value; complex types are JSON-encoded."""
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    return "" if value is None else str(value)


# --- Markdown -------------------------------------------------------------
def to_markdown(obj: Any) -> str:
    """Render a structured prompt ``dict`` as readable Markdown.

    Keys become ``##`` headings (title-cased), list values become bullet lists,
    and scalar values become paragraphs.
    """
    if not isinstance(obj, dict):
        return str(obj)
    parts: list[str] = []
    for key, value in obj.items():
        heading = str(key).replace("_", " ").title()
        parts.append(f"## {heading}")
        if isinstance(value, list):
            parts.append("\n".join(f"- {item}" for item in value))
        elif isinstance(value, dict):
            parts.append(
                "\n".join(f"- **{k}**: {v}" for k, v in value.items())
            )
        else:
            parts.append(str(value))
    return "\n\n".join(parts)


# --- Dispatcher -----------------------------------------------------------
def render(obj: Any, fmt: str) -> str:
    """Render ``obj`` to the requested format.

    Args:
        obj: A JSON-serialisable structure (typically a dict of sections).
        fmt: One of :data:`RENDER_FORMATS` (case-insensitive).

    Returns:
        The serialised string.

    Raises:
        ValueError: if ``fmt`` is not supported.
    """
    key = fmt.strip().lower()
    if key == "json":
        return json.dumps(obj, indent=2, ensure_ascii=False)
    if key in ("markdown", "md"):
        return to_markdown(obj)
    if key in ("yaml", "yml"):
        return to_yaml(obj)
    if key == "xml":
        return to_xml(obj)
    if key == "csv":
        return to_csv(obj)
    valid = ", ".join(RENDER_FORMATS)
    raise ValueError(f"unknown format {fmt!r}; supported: {valid}")


# --- Advanced scaffolds ---------------------------------------------------
_STRUCTURED_OUTPUT = """\
## Role
You are {role}.

## Task
{task}

## Output Format
Return ONLY valid JSON matching this schema — no prose, no code fences:
{{
  "summary": "string",
  "items": [{{ "name": "string", "value": "string" }}],
  "confidence": 0.0
}}

## Constraints
- Do not include any text outside the JSON object.
- Use null for unknown values; never invent data.
"""

_TOOL_CALLING = """\
## Role
You are {role} with access to external tools.

## Available Tools
- search(query: string): returns relevant documents.
- calculator(expression: string): evaluates arithmetic.

## Task
{task}

## Instructions
1. Decide whether a tool is required before answering.
2. If so, emit a single tool call as JSON: {{"tool": "<name>", "args": {{...}}}}.
3. Wait for the tool result, then continue reasoning.
4. When you have enough information, give the final answer.
"""

_FUNCTION_CALLING = """\
## Role
You are {role}.

## Task
{task}

## Function Specification
You may call the function `get_data` defined as:
{{
  "name": "get_data",
  "description": "Fetch records for a given entity.",
  "parameters": {{
    "type": "object",
    "properties": {{ "entity": {{ "type": "string" }} }},
    "required": ["entity"]
  }}
}}

## Instructions
- Respond with a function call when external data is needed.
- Otherwise answer directly.
"""

_API_PROMPT = """\
{{
  "model": "{model}",
  "messages": [
    {{ "role": "system", "content": "You are {role}." }},
    {{ "role": "user", "content": "{task}" }}
  ],
  "temperature": 0.2,
  "max_tokens": 1024
}}
"""

_SCAFFOLDS = {
    "structured_output": _STRUCTURED_OUTPUT,
    "tool_calling": _TOOL_CALLING,
    "function_calling": _FUNCTION_CALLING,
    "api_prompt": _API_PROMPT,
}


def get_template(
    name: str,
    *,
    role: str = "an expert assistant",
    task: str = "<describe the task>",
    model: str = "gpt",
) -> str:
    """Return a ready-to-use advanced template, filled with the given values.

    Args:
        name: One of :data:`TEMPLATE_NAMES`.
        role: Role to inject into the scaffold.
        task: Task description to inject.
        model: Model id (used by the ``api_prompt`` scaffold).

    Raises:
        ValueError: if ``name`` is not a known scaffold.
    """
    key = name.strip().lower()
    if key not in _SCAFFOLDS:
        valid = ", ".join(TEMPLATE_NAMES)
        raise ValueError(f"unknown template {name!r}; available: {valid}")
    return _SCAFFOLDS[key].format(role=role, task=task, model=model)
