"""Tests for the prompt schema (promptforge.schema)."""

from __future__ import annotations

import unittest

from promptforge.schema import Difficulty, Prompt

VALID = {
    "id": "sample-prompt",
    "title": "Sample Prompt",
    "description": "A valid sample prompt used for testing the schema.",
    "category": "programming",
    "difficulty": "beginner",
    "body": "## Task\nDo the thing with {input}.",
    "expected_output": "A description of the expected output.",
    "supported_models": ["all"],
    "example": "A worked example.",
    "best_practices": ["Be specific."],
    "common_mistakes": ["Being vague."],
    "version": "1.0.0",
    "tags": ["test", "sample"],
    "related_prompts": [],
}


class SchemaTests(unittest.TestCase):
    def test_round_trip(self) -> None:
        prompt = Prompt.from_dict(VALID)
        self.assertEqual(prompt.difficulty, Difficulty.BEGINNER)
        again = Prompt.from_dict(prompt.to_dict())
        self.assertEqual(prompt, again)

    def test_to_dict_renders_enum_as_string(self) -> None:
        data = Prompt.from_dict(VALID).to_dict()
        self.assertEqual(data["difficulty"], "beginner")

    def test_valid_prompt_has_no_problems(self) -> None:
        self.assertTrue(Prompt.from_dict(VALID).is_valid)

    def test_invalid_id_detected(self) -> None:
        bad = {**VALID, "id": "Not A Slug"}
        problems = Prompt.from_dict(bad).validate()
        self.assertTrue(any("slug" in p for p in problems))

    def test_invalid_version_detected(self) -> None:
        bad = {**VALID, "version": "v1"}
        problems = Prompt.from_dict(bad).validate()
        self.assertTrue(any("semantic" in p for p in problems))

    def test_empty_required_field_detected(self) -> None:
        bad = {**VALID, "body": "   "}
        problems = Prompt.from_dict(bad).validate()
        self.assertTrue(any("body" in p for p in problems))

    def test_unknown_difficulty_raises(self) -> None:
        with self.assertRaises(ValueError):
            Difficulty.coerce("wizard")


if __name__ == "__main__":
    unittest.main()
